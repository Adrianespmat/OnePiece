package com.daw.onepiece.dao.impl;

import com.daw.onepiece.dao.interfaces.IIslaDAO;
import com.daw.onepiece.dtos.IslaDTO;
import com.daw.onepiece.entities.IslaEntity;
import com.daw.onepiece.repositorios.IIslaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.stream.Collectors;

@Repository
public class IslaDAOImpl implements IIslaDAO {

    @Autowired
    private IIslaRepository islaRepository;

    @Override
    public List<IslaDTO> obtenerTodasIslas() {
        List<IslaEntity> islasEntities = islaRepository.findAll();
        
        return islasEntities.stream()
                .map(this::convertirADTO)
                .collect(Collectors.toList());
    }

    @Override
    public IslaDTO obtenerIslaPorId(Integer id) {
        return islaRepository.findById(id)
                .map(this::convertirADTO)
                .orElse(null);
    }

    @Override
    public IslaDTO obtenerIslaPorNombre(String nombre) {
        IslaEntity islaEntity = islaRepository.findByNombre(nombre);
        return islaEntity != null ? convertirADTO(islaEntity) : null;
    }

    private IslaDTO convertirADTO(IslaEntity entity) {
        return new IslaDTO(
            entity.getId(),
            entity.getNombre()
        );
    }
}
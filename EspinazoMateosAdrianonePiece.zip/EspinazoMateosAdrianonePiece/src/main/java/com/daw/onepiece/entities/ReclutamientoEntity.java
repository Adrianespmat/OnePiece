package com.daw.onepiece.entities;

import jakarta.persistence.*;

@Entity
@Table(name = "Reclutamiento")
public class ReclutamientoEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "pirata_id")
    private PirataEntity pirata;

    @ManyToOne
    @JoinColumn(name = "tripulacion_id")
    private TripulacionEntity tripulacion;

    @Column(name = "rol")
    private String rol;

    @Column(name = "`esMiembroActual`")
    private Boolean esMiembroActual;

    public ReclutamientoEntity() {
    }

    public ReclutamientoEntity(Integer id, PirataEntity pirata, TripulacionEntity tripulacion, 
                               String rol, Boolean esMiembroActual) {
        this.id = id;
        this.pirata = pirata;
        this.tripulacion = tripulacion;
        this.rol = rol;
        this.esMiembroActual = esMiembroActual;
    }

    // Getters y Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public PirataEntity getPirata() {
        return pirata;
    }

    public void setPirata(PirataEntity pirata) {
        this.pirata = pirata;
    }

    public TripulacionEntity getTripulacion() {
        return tripulacion;
    }

    public void setTripulacion(TripulacionEntity tripulacion) {
        this.tripulacion = tripulacion;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public Boolean getEsMiembroActual() {
        return esMiembroActual;
    }

    public void setEsMiembroActual(Boolean esMiembroActual) {
        this.esMiembroActual = esMiembroActual;
    }
}
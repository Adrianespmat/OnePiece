package com.daw.onepiece.servicio.interfaces;

import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.dtos.DetalleTripulacionDTO;
import com.daw.onepiece.dtos.PirataDTO;

import java.util.List;

public interface ITripulacionService {
    List<TripulacionDTO> obtenerTodasTripulaciones();
    DetalleTripulacionDTO obtenerDetalleTripulacion(Integer id);
    Integer crearTripulacion(TripulacionDTO tripulacionDTO);
    Integer actualizarTripulacion(TripulacionDTO tripulacionDTO);
    void eliminarTripulacion(Integer id);
    void agregarMiembro(Integer tripulacionId, Integer pirataId, String rol);
    void eliminarMiembro(Integer reclutamientoId);
    List<PirataDTO> obtenerPiratasDisponibles();
}
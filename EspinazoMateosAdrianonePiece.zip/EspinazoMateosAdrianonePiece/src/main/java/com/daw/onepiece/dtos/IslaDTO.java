package com.daw.onepiece.dtos;

public class IslaDTO {
    private Integer id;
    private String nombre;
    
    // Constructor con parámetros (IMPORTANTE: Lo que pide el error)
    public IslaDTO(Integer id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }
    
    // Constructor vacío (necesario para Spring)
    public IslaDTO() {}
    
    // Getters y Setters
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public String toString() {
        return "IslaDTO{" +
               "id=" + id +
               ", nombre='" + nombre + '\'' +
               '}';
    }
}
package com.daw.onepiece.servicio.impl;

import com.daw.onepiece.dao.interfaces.ITripulacionDAO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.dtos.DetalleTripulacionDTO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.servicio.interfaces.ITripulacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TripulacionServiceImpl implements ITripulacionService {

    @Autowired
    private ITripulacionDAO tripulacionDAO;

    @Override
    public List<TripulacionDTO> obtenerTodasTripulaciones() {
        System.out.println("✅ Service: obtenerTodasTripulaciones");
        return tripulacionDAO.obtenerTodasTripulacionesConMiembros();
    }

    @Override
    public DetalleTripulacionDTO obtenerDetalleTripulacion(Integer id) {
        System.out.println("✅ Service: obtenerDetalleTripulacion ID: " + id);
        return tripulacionDAO.obtenerDetalleTripulacion(id);
    }

    @Override
    public Integer crearTripulacion(TripulacionDTO tripulacionDTO) {
        System.out.println("✅ Service: crearTripulacion");
        return tripulacionDAO.crearTripulacion(tripulacionDTO);
    }

    @Override
    public Integer actualizarTripulacion(TripulacionDTO tripulacionDTO) {
        System.out.println("✅ Service: actualizarTripulacion ID: " + tripulacionDTO.getId());
        return tripulacionDAO.actualizarTripulacion(tripulacionDTO);
    }

    @Override
    public void eliminarTripulacion(Integer id) {
        System.out.println("✅ Service: eliminarTripulacion ID: " + id);
        tripulacionDAO.eliminarTripulacion(id);
    }

    @Override
    public void agregarMiembro(Integer tripulacionId, Integer pirataId, String rol) {
        System.out.println("✅ Service: agregarMiembro - Tripulación: " + tripulacionId + ", Pirata: " + pirataId);
        tripulacionDAO.agregarMiembroATripulacion(tripulacionId, pirataId, rol);
    }

    @Override
    public void eliminarMiembro(Integer reclutamientoId) {
        System.out.println("✅ Service: eliminarMiembro - Reclutamiento: " + reclutamientoId);
        tripulacionDAO.eliminarMiembroDeTripulacion(reclutamientoId);
    }

    @Override
    public List<PirataDTO> obtenerPiratasDisponibles() {
        System.out.println("✅ Service: obtenerPiratasDisponibles");
        return tripulacionDAO.obtenerPiratasDisponibles();
    }
}
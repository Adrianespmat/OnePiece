package com.daw.onepiece.dao.impl;

import com.daw.onepiece.dao.interfaces.ITripulacionDAO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.dtos.DetalleTripulacionDTO;
import com.daw.onepiece.dtos.MiembroTripulacionDTO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.entities.TripulacionEntity;
import com.daw.onepiece.entities.ReclutamientoEntity;
import com.daw.onepiece.entities.PirataEntity;
import com.daw.onepiece.repositorios.ITripulacionRepository;
import com.daw.onepiece.repositorios.IReclutamientoRepository;
import com.daw.onepiece.repositorios.IPiratasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public class TripulacionDAOImpl implements ITripulacionDAO {

    @Autowired
    private ITripulacionRepository tripulacionRepository;
    
    @Autowired
    private IReclutamientoRepository reclutamientoRepository;
    
    @Autowired
    private IPiratasRepository piratasRepository;

    @Override
    public List<TripulacionDTO> obtenerTodasTripulacionesConMiembros() {
        try {
            List<TripulacionDTO> tripulaciones = tripulacionRepository.findTripulacionesConFiltros(
                null, null, null, null);
            return tripulaciones != null ? tripulaciones : List.of();
        } catch (Exception e) {
            System.out.println("❌ Error en obtenerTodasTripulacionesConMiembros: " + e.getMessage());
            e.printStackTrace();
            return List.of();
        }
    }

    @Override
    public DetalleTripulacionDTO obtenerDetalleTripulacion(Integer id) { // ✅ CAMBIADO
        try {
            TripulacionDTO tripulacionDTO = tripulacionRepository.findTripulacionByIdWithMemberCount(id);
            
            if (tripulacionDTO == null) {
                return null;
            }
            
            List<MiembroTripulacionDTO> miembros = tripulacionRepository.findMiembrosByTripulacionId(id);
            List<PirataDTO> piratasDisponibles = tripulacionRepository.findPiratasSinTripulacion();
            
            DetalleTripulacionDTO detalle = new DetalleTripulacionDTO();
            detalle.setTripulacion(tripulacionDTO);
            detalle.setMiembros(miembros != null ? miembros : List.of());
            detalle.setPiratasDisponibles(piratasDisponibles != null ? piratasDisponibles : List.of());
            
            return detalle;
        } catch (Exception e) {
            System.out.println("❌ Error en obtenerDetalleTripulacion: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    @Override
    @Transactional
    public Integer crearTripulacion(TripulacionDTO tripulacionDTO) { // ✅ CAMBIADO
        try {
            TripulacionEntity tripulacion = new TripulacionEntity();
            tripulacion.setNombre(tripulacionDTO.getNombre());
            tripulacion.setBarco(tripulacionDTO.getBarco());
            tripulacion.setEstaActiva(tripulacionDTO.getEstaActiva() != null ? tripulacionDTO.getEstaActiva() : true);
            
            TripulacionEntity saved = tripulacionRepository.save(tripulacion);
            System.out.println("✅ Tripulación creada con ID: " + saved.getId());
            return saved.getId();
        } catch (Exception e) {
            System.out.println("❌ Error en crearTripulacion: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    @Override
    @Transactional
    public Integer actualizarTripulacion(TripulacionDTO tripulacionDTO) { // ✅ CAMBIADO
        try {
            Optional<TripulacionEntity> optional = tripulacionRepository.findById(tripulacionDTO.getId());
            if (optional.isPresent()) {
                TripulacionEntity tripulacion = optional.get();
                tripulacion.setNombre(tripulacionDTO.getNombre());
                tripulacion.setBarco(tripulacionDTO.getBarco());
                tripulacion.setEstaActiva(tripulacionDTO.getEstaActiva());
                
                TripulacionEntity saved = tripulacionRepository.save(tripulacion);
                System.out.println("✅ Tripulación actualizada ID: " + saved.getId());
                return saved.getId();
            }
            return null;
        } catch (Exception e) {
            System.out.println("❌ Error en actualizarTripulacion: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    @Override
    @Transactional
    public void eliminarTripulacion(Integer id) { // ✅ CAMBIADO
        try {
            Optional<TripulacionEntity> optional = tripulacionRepository.findById(id);
            if (optional.isPresent()) {
                TripulacionEntity tripulacion = optional.get();
                tripulacion.setEstaActiva(false);
                tripulacionRepository.save(tripulacion);
                System.out.println("✅ Tripulación ID " + id + " marcada como inactiva");
            }
        } catch (Exception e) {
            System.out.println("❌ Error en eliminarTripulacion: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    @Transactional
    public void agregarMiembroATripulacion(Integer tripulacionId, Integer pirataId, String rol) { // ✅ CAMBIADO
        try {
            tripulacionRepository.desactivarReclutamientosDelPirata(pirataId);
            
            Optional<TripulacionEntity> optionalTripulacion = tripulacionRepository.findById(tripulacionId);
            Optional<PirataEntity> optionalPirata = piratasRepository.findById(pirataId);
            
            if (optionalTripulacion.isPresent() && optionalPirata.isPresent()) {
                ReclutamientoEntity nuevoReclutamiento = new ReclutamientoEntity();
                nuevoReclutamiento.setTripulacion(optionalTripulacion.get());
                nuevoReclutamiento.setPirata(optionalPirata.get());
                nuevoReclutamiento.setRol(rol);
                nuevoReclutamiento.setEsMiembroActual(true);
                
                reclutamientoRepository.save(nuevoReclutamiento);
                System.out.println("✅ Pirata ID " + pirataId + " añadido a tripulación ID " + tripulacionId);
            }
        } catch (Exception e) {
            System.out.println("❌ Error en agregarMiembroATripulacion: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    @Transactional
    public void eliminarMiembroDeTripulacion(Integer reclutamientoId) {
        try {
            Optional<ReclutamientoEntity> optional = reclutamientoRepository.findById(reclutamientoId);
            if (optional.isPresent()) {
                ReclutamientoEntity reclutamiento = optional.get();
                reclutamiento.setEsMiembroActual(false);
                reclutamientoRepository.save(reclutamiento);
                System.out.println("✅ Miembro eliminado (reclutamiento ID: " + reclutamientoId + ")");
            }
        } catch (Exception e) {
            System.out.println("❌ Error en eliminarMiembroDeTripulacion: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public List<PirataDTO> obtenerPiratasDisponibles() {
        try {
            List<PirataDTO> piratas = tripulacionRepository.findPiratasSinTripulacion();
            return piratas != null ? piratas : List.of();
        } catch (Exception e) {
            System.out.println("❌ Error en obtenerPiratasDisponibles: " + e.getMessage());
            e.printStackTrace();
            return List.of();
        }
    }
}
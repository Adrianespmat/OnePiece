package com.daw.onepiece.servicio.interfaces;

import com.daw.onepiece.dtos.PirataDTO;
import java.util.List;

public interface IPiratasService {
    List<PirataDTO> buscarPiratasConFiltros(Integer id, String nombre, String frutadeldiablo, Boolean esta_Activo);
    List<PirataDTO> TodosLosPiratas();
    Integer crearPirata(PirataDTO pirataDTO);
    Integer actualizarPirata(PirataDTO pirataDTO);
    void eliminarPirata(Integer id);
    PirataDTO obtenerPirataPorId(Integer id);
}
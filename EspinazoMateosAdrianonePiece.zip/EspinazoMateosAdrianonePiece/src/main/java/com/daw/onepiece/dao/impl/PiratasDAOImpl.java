package com.daw.onepiece.dao.impl;

import com.daw.onepiece.dao.interfaces.IPiratasDAO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.entities.PirataEntity;
import com.daw.onepiece.entities.IslaEntity;
import com.daw.onepiece.repositorios.IPiratasRepository;
import com.daw.onepiece.repositorios.IIslaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class PiratasDAOImpl implements IPiratasDAO {

    @Autowired
    private IPiratasRepository piratasRepository;
    
    @Autowired
    private IIslaRepository islaRepository;

    @Override
    public ArrayList<PirataDTO> buscarPiratasConFiltros(Integer id, String nombre, String frutadeldiablo, Boolean esta_Activo) {
        List<PirataDTO> resultados = piratasRepository.buscarPiratasConFiltros(id, nombre, frutadeldiablo, esta_Activo);
        return resultados != null ? new ArrayList<>(resultados) : new ArrayList<>();
    }

    @Override
    @Transactional
    public Integer crearPirata(PirataDTO pirataDTO) {
        try {
            PirataEntity pirataEntity = new PirataEntity();
            
            pirataEntity.setNombre(pirataDTO.getNombre());
            
            // Según PDF: "Si no introduce Fruta De Diablo en la BD deberá guardarse como NULL"
            String fruta = pirataDTO.getFrutaDiablo();
            pirataEntity.setFrutaDelDiablo(fruta != null && !fruta.trim().isEmpty() ? fruta : null);
            
            pirataEntity.setFechaNacimiento(pirataDTO.getFechaNacimiento());
            
            // Por defecto, nuevo pirata es activo (según PDF)
            Boolean activo = pirataDTO.getEstaActivo();
            pirataEntity.setEstaActivo(activo != null ? activo : true);
            
            // Asignar isla
            if (pirataDTO.getIslaId() != null) {
                Optional<IslaEntity> islaOptional = islaRepository.findById(pirataDTO.getIslaId());
                islaOptional.ifPresent(pirataEntity::setIsla);
            }
            
            PirataEntity pirataGuardado = piratasRepository.save(pirataEntity);
            return pirataGuardado.getId();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    @Transactional
    public Integer actualizarPirata(PirataDTO pirataDTO) {
        try {
            Optional<PirataEntity> optionalPirata = piratasRepository.findById(pirataDTO.getId());
            if (optionalPirata.isPresent()) {
                PirataEntity pirataEntity = optionalPirata.get();
                
                pirataEntity.setNombre(pirataDTO.getNombre());
                
                // Según PDF: mantener NULL si no hay fruta
                String fruta = pirataDTO.getFrutaDiablo();
                pirataEntity.setFrutaDelDiablo(fruta != null && !fruta.trim().isEmpty() ? fruta : null);
                
                pirataEntity.setFechaNacimiento(pirataDTO.getFechaNacimiento());
                pirataEntity.setEstaActivo(pirataDTO.getEstaActivo());

                if (pirataDTO.getIslaId() != null) {
                    islaRepository.findById(pirataDTO.getIslaId()).ifPresent(pirataEntity::setIsla);
                }

                piratasRepository.save(pirataEntity);
                return pirataEntity.getId();
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    @Transactional
    public void eliminarPirata(Integer id) {
        try {
            Optional<PirataEntity> optionalPirata = piratasRepository.findById(id);
            
            if (optionalPirata.isPresent()) {
                PirataEntity pirataEntity = optionalPirata.get();
                // BORRADO LÓGICO según PDF: marcar como inactivo
                pirataEntity.setEstaActivo(false);
                piratasRepository.save(pirataEntity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public PirataDTO obtenerPirataPorId(Integer id) {
        try {
            Optional<PirataEntity> optionalPirata = piratasRepository.findById(id);
            
            if (optionalPirata.isPresent()) {
                PirataEntity pirata = optionalPirata.get();
                
                // Obtener tripulación actual si existe
                String tripulacionActual = null;
                String rolEnTripulacion = null;
                
                // Necesitarías un método en el repository para obtener el reclutamiento activo
                // Por ahora, dejamos null
                
                return new PirataDTO(
                    pirata.getId(),
                    pirata.getNombre(),
                    pirata.getFrutaDelDiablo(),
                    pirata.getFechaNacimiento(),
                    pirata.getEstaActivo(),
                    pirata.getIsla() != null ? pirata.getIsla().getId() : null,
                    pirata.getIsla() != null ? pirata.getIsla().getNombre() : null,
                    tripulacionActual,
                    rolEnTripulacion
                );
            }
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
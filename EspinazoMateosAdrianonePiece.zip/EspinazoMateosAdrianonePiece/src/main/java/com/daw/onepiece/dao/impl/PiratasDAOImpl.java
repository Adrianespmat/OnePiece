package com.daw.onepiece.dao.impl;

import com.daw.onepiece.dao.interfaces.IPiratasDAO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.entities.PirataEntity;
import com.daw.onepiece.entities.IslaEntity;
import com.daw.onepiece.repositorios.IPiratasRepository;
import com.daw.onepiece.repositorios.IIslaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class PiratasDAOImpl implements IPiratasDAO {

    @Autowired
    private IPiratasRepository piratasRepository;
    
    @Autowired
    private IIslaRepository islaRepository;

    @Override
    public ArrayList<PirataDTO> buscarPiratasConFiltros(Integer id, String nombre, String frutadeldiablo, Boolean esta_Activo) {
        List<PirataDTO> resultados = piratasRepository.buscarPiratasConFiltros(id, nombre, frutadeldiablo, esta_Activo);
        return new ArrayList<>(resultados);
    }

    @Override
    @Transactional
    public Integer crearPirata(PirataDTO pirataDTO) {
        PirataEntity pirataEntity = new PirataEntity();
        
        pirataEntity.setNombre(pirataDTO.getNombre());
        pirataEntity.setFrutaDelDiablo(pirataDTO.getFrutaDelDiablo());
        pirataEntity.setFechaNacimiento(pirataDTO.getFechaNacimiento());
        pirataEntity.setEstaActivo(pirataDTO.getEstaActivo() != null ? pirataDTO.getEstaActivo() : true);
        
        // CORREGIDO: Buscar por ID, no por nombre
        if (pirataDTO.getIslaId() != null) {
            Optional<IslaEntity> islaOptional = islaRepository.findById(pirataDTO.getIslaId());
            if (islaOptional.isPresent()) {
                pirataEntity.setIsla(islaOptional.get());
            }
        }
        
        PirataEntity pirataGuardado = piratasRepository.save(pirataEntity);
        return pirataGuardado.getId();
    }

    @Override
    @Transactional
    public Integer actualizarPirata(PirataDTO pirataDTO) {
        Optional<PirataEntity> optionalPirata = piratasRepository.findById(pirataDTO.getId());
        if (optionalPirata.isPresent()) {
            PirataEntity pirataEntity = optionalPirata.get();
            pirataEntity.setNombre(pirataDTO.getNombre());
            pirataEntity.setFrutaDelDiablo(pirataDTO.getFrutaDelDiablo());
            pirataEntity.setFechaNacimiento(pirataDTO.getFechaNacimiento());
            pirataEntity.setEstaActivo(pirataDTO.getEstaActivo());

            if (pirataDTO.getIslaId() != null) {
                islaRepository.findById(pirataDTO.getIslaId()).ifPresent(pirataEntity::setIsla);
            }

            piratasRepository.save(pirataEntity);
            return pirataEntity.getId();
        }
        return null;
    }


    @Override
    @Transactional
    public void eliminarPirata(Integer id) {
        Optional<PirataEntity> optionalPirata = piratasRepository.findById(id);
        
        if (optionalPirata.isPresent()) {
            PirataEntity pirataEntity = optionalPirata.get();
            pirataEntity.setEstaActivo(false);
            piratasRepository.save(pirataEntity);
        }
    }

    @Override
    public PirataDTO obtenerPirataPorId(Integer id) {
        Optional<PirataEntity> optionalPirata = piratasRepository.findById(id);
        
        if (optionalPirata.isPresent()) {
            PirataEntity pirata = optionalPirata.get();
            return new PirataDTO(
                pirata.getId(),
                pirata.getNombre(),
                pirata.getFrutaDelDiablo(),
                pirata.getFechaNacimiento(),
                pirata.getEstaActivo(),
                pirata.getIsla() != null ? pirata.getIsla().getId() : null, // CORREGIDO: Enviar ID
                pirata.getIsla() != null ? pirata.getIsla().getNombre() : null, // Nombre para mostrar
                null, // Tripulación 
                null  // Rol 
            );
        }
        
        return null;
    }
}
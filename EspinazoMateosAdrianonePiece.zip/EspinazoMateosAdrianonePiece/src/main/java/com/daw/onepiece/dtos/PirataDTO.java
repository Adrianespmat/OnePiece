package com.daw.onepiece.dtos;

import java.time.LocalDate;

public class PirataDTO {
    private Integer id;
    private String nombre;
    private String frutadeldiablo;
    private LocalDate fechaNacimiento;
    private Boolean esta_Activo;
    private Integer islaId;          
    private String islaNombre;       
    private String islaOrigen;       
    private String tripulacionActual;
    private String rolEnTripulacion;
    
    // Constructor para LISTADO (8 parámetros - compatibilidad con JPQL)
    public PirataDTO(Integer id, String nombre, String frutadeldiablo, LocalDate fechaNacimiento, 
                     Boolean esta_Activo, String islaOrigen, String tripulacionActual, String rolEnTripulacion) {
        this.id = id;
        this.nombre = nombre;
        this.frutadeldiablo = frutadeldiablo;
        this.fechaNacimiento = fechaNacimiento;
        this.esta_Activo = esta_Activo;
        this.islaOrigen = islaOrigen;
        this.islaNombre = islaOrigen; // Mismo valor
        this.tripulacionActual = tripulacionActual;
        this.rolEnTripulacion = rolEnTripulacion;
    }
    
    // Constructor para INSERCIÓN/EDICIÓN (9 parámetros)
    public PirataDTO(Integer id, String nombre, String frutadeldiablo, LocalDate fechaNacimiento, 
                     Boolean esta_Activo, Integer islaId, String islaNombre,
                     String tripulacionActual, String rolEnTripulacion) {
        this.id = id;
        this.nombre = nombre;
        this.frutadeldiablo = frutadeldiablo;
        this.fechaNacimiento = fechaNacimiento;
        this.esta_Activo = esta_Activo;
        this.islaId = islaId;
        this.islaNombre = islaNombre;
        this.islaOrigen = islaNombre;
        this.tripulacionActual = tripulacionActual;
        this.rolEnTripulacion = rolEnTripulacion;
    }
    
    // Constructor vacío
    public PirataDTO() {}

    // Getters y Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFrutaDelDiablo() {
        return frutadeldiablo;
    }

    public void setFrutaDelDiablo(String frutadeldiablo) {
        this.frutadeldiablo = frutadeldiablo;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Boolean getEstaActivo() {
        return esta_Activo;
    }

    public void setEstaActivo(Boolean estaactivo) {
        this.esta_Activo = estaactivo;
    }

    public Integer getIslaId() {
        return islaId;
    }

    public void setIslaId(Integer islaId) {
        this.islaId = islaId;
    }

    public String getIslaNombre() {
        return islaNombre != null ? islaNombre : islaOrigen;
    }

    public void setIslaNombre(String islaNombre) {
        this.islaNombre = islaNombre;
    }

    public String getIslaOrigen() {
        return islaOrigen != null ? islaOrigen : islaNombre;
    }

    public void setIslaOrigen(String islaOrigen) {
        this.islaOrigen = islaOrigen;
        if (this.islaNombre == null) {
            this.islaNombre = islaOrigen;
        }
    }

    public String getTripulacionActual() {
        return tripulacionActual;
    }

    public void setTripulacionActual(String tripulacionActual) {
        this.tripulacionActual = tripulacionActual;
    }

    public String getRolEnTripulacion() {
        return rolEnTripulacion;
    }

    public void setRolEnTripulacion(String rolEnTripulacion) {
        this.rolEnTripulacion = rolEnTripulacion;
    }
    
    // Métodos auxiliares
    public String getFechaNacimientoString() {
        return fechaNacimiento != null ? fechaNacimiento.toString() : "";
    }
    
    public String getEstadoTexto() {
        return esta_Activo != null && esta_Activo ? "Activo" : "Inactivo";
    }
    
    public boolean getTieneFrutaDelDiablo() {
        return frutadeldiablo != null && !frutadeldiablo.trim().isEmpty();
    }
    
    // Para compatibilidad
    public String getIsla() {
        return getIslaOrigen();
    }
    
    public void setIsla(String isla) {
        setIslaOrigen(isla);
    }
}
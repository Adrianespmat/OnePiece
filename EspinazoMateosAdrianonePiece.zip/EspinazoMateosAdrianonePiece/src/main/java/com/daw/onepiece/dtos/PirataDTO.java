package com.daw.onepiece.dtos;

import java.time.LocalDate;

public class PirataDTO {
    private Integer id;
    private String nombre;
    private String frutadeldiablo;
    private LocalDate fechaNacimiento;
    private Boolean esta_Activo;
    private Integer islaId;          
    private String islaNombre;       
    private String islaOrigen;       
    private String tripulacionActual;
    private String rolEnTripulacion;
    
    public PirataDTO(Integer id, String nombre, String frutadeldiablo, LocalDate fechaNacimiento, 
                     Boolean esta_Activo, String islaOrigen, String tripulacionActual, String rolEnTripulacion) {
        this.id = id;
        this.nombre = nombre;
        this.frutadeldiablo = frutadeldiablo;
        this.fechaNacimiento = fechaNacimiento;
        this.esta_Activo = esta_Activo;
        this.islaOrigen = islaOrigen;
        this.islaNombre = islaOrigen;
        this.tripulacionActual = tripulacionActual;
        this.rolEnTripulacion = rolEnTripulacion;
    }
    
    public PirataDTO(Integer id, String nombre, String frutadeldiablo, LocalDate fechaNacimiento, 
                     Boolean esta_Activo, Integer islaId, String islaNombre,
                     String tripulacionActual, String rolEnTripulacion) {
        this.id = id;
        this.nombre = nombre;
        this.frutadeldiablo = frutadeldiablo;
        this.fechaNacimiento = fechaNacimiento;
        this.esta_Activo = esta_Activo;
        this.islaId = islaId;
        this.islaNombre = islaNombre;
        this.islaOrigen = islaNombre;
        this.tripulacionActual = tripulacionActual;
        this.rolEnTripulacion = rolEnTripulacion;
    }
    
    public PirataDTO() {}

    // Getters y Setters básicos
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Boolean getEstaActivo() {
        return esta_Activo;
    }

    public void setEstaActivo(Boolean estaactivo) {
        this.esta_Activo = estaactivo;
    }

    public Integer getIslaId() {
        return islaId;
    }

    public void setIslaId(Integer islaId) {
        this.islaId = islaId;
    }

    public String getIslaNombre() {
        return islaNombre != null ? islaNombre : islaOrigen;
    }

    public void setIslaNombre(String islaNombre) {
        this.islaNombre = islaNombre;
    }

    public String getIslaOrigen() {
        return islaOrigen != null ? islaOrigen : islaNombre;
    }

    public void setIslaOrigen(String islaOrigen) {
        this.islaOrigen = islaOrigen;
        if (this.islaNombre == null) {
            this.islaNombre = islaOrigen;
        }
    }

    public String getTripulacionActual() {
        return tripulacionActual;
    }

    public void setTripulacionActual(String tripulacionActual) {
        this.tripulacionActual = tripulacionActual;
    }

    public String getRolEnTripulacion() {
        return rolEnTripulacion;
    }

    public void setRolEnTripulacion(String rolEnTripulacion) {
        this.rolEnTripulacion = rolEnTripulacion;
    }
    
    // ✅ MÉTODOS NUEVOS PARA LAS VISTAS
    
    public String getFrutaDiablo() {
        return frutadeldiablo;
    }
    
    public void setFrutaDiablo(String frutaDiablo) {
        this.frutadeldiablo = frutaDiablo;
    }
    
    // Para checkbox: activo == 1
    public Integer getActivo() {
        return esta_Activo != null && esta_Activo ? 1 : 0;
    }
    
    public void setActivo(Integer activo) {
        this.esta_Activo = (activo != null && activo == 1);
    }
    
    // Para las vistas que usan pirata.isla
    public String getIsla() {
        if (islaOrigen != null && !islaOrigen.isEmpty()) {
            return islaOrigen;
        }
        if (islaNombre != null && !islaNombre.isEmpty()) {
            return islaNombre;
        }
        return "Desconocida";
    }
    
    public void setIsla(String isla) {
        this.islaOrigen = isla;
        this.islaNombre = isla;
    }
    
    // Para input type="date" necesita formato YYYY-MM-DD
    public String getFechaNacimientoFormatted() {
        return fechaNacimiento != null ? fechaNacimiento.toString() : "";
    }
    
    public String getEstadoTexto() {
        return esta_Activo != null && esta_Activo ? "Activo" : "Inactivo";
    }
    
    public boolean getTieneFrutaDelDiablo() {
        return frutadeldiablo != null && !frutadeldiablo.trim().isEmpty();
    }
    
    // Para las vistas que usan pirata.idIsla
    public Integer getIdIsla() {
        return islaId;
    }
    
    // Para las vistas que usan pirata.tripulacion
    public String getTripulacion() {
        return tripulacionActual != null ? tripulacionActual : "Sin tripulación";
    }
    
    @Override
    public String toString() {
        return "PirataDTO{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", frutadeldiablo='" + frutadeldiablo + '\'' +
                ", esta_Activo=" + esta_Activo +
                ", islaOrigen='" + islaOrigen + '\'' +
                ", islaNombre='" + islaNombre + '\'' +
                '}';
    }
}
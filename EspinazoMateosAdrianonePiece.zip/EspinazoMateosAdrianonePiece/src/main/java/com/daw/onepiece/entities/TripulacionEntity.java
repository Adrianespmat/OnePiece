package com.daw.onepiece.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "Tripulacion") 
public class TripulacionEntity {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id; // ✅ CAMBIADO de Long a Integer

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "barco") 
    private String barco;

    @Column(name = "`estaActiva`") 
    private Boolean estaActiva;

    @OneToMany(mappedBy = "tripulacion")
    private List<ReclutamientoEntity> reclutamientos;

    public TripulacionEntity() {
    }

    public TripulacionEntity(Integer id, String nombre, String barco, Boolean estaActiva) { // ✅ CAMBIADO
        this.id = id;
        this.nombre = nombre;
        this.barco = barco;
        this.estaActiva = estaActiva;
    }

    // Getters y setters
    public Integer getId() { // ✅ CAMBIADO
        return id;
    }

    public void setId(Integer id) { // ✅ CAMBIADO
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getBarco() {
        return barco;
    }

    public void setBarco(String barco) {
        this.barco = barco;
    }

    public Boolean getEstaActiva() {
        return estaActiva;
    }

    public void setEstaActiva(Boolean estaActiva) {
        this.estaActiva = estaActiva;
    }

    public List<ReclutamientoEntity> getReclutamientos() {
        return reclutamientos;
    }

    public void setReclutamientos(List<ReclutamientoEntity> reclutamientos) {
        this.reclutamientos = reclutamientos;
    }
}
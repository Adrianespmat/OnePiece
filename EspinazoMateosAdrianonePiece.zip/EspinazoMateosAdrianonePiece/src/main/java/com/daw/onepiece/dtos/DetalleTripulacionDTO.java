package com.daw.onepiece.dtos;

import java.util.List;

public class DetalleTripulacionDTO {
    private TripulacionDTO tripulacion;
    private List<MiembroTripulacionDTO> miembros;
    private List<PirataDTO> piratasDisponibles;
    
    public DetalleTripulacionDTO() {
    }
    
    public DetalleTripulacionDTO(TripulacionDTO tripulacion, List<MiembroTripulacionDTO> miembros) {
        this.tripulacion = tripulacion;
        this.miembros = miembros;
    }
    
    public DetalleTripulacionDTO(TripulacionDTO tripulacion, List<MiembroTripulacionDTO> miembros, 
                                 List<PirataDTO> piratasDisponibles) {
        this.tripulacion = tripulacion;
        this.miembros = miembros;
        this.piratasDisponibles = piratasDisponibles;
    }
    
    // Getters y Setters
    public TripulacionDTO getTripulacion() {
        return tripulacion;
    }
    
    public void setTripulacion(TripulacionDTO tripulacion) {
        this.tripulacion = tripulacion;
    }
    
    public List<MiembroTripulacionDTO> getMiembros() {
        return miembros;
    }
    
    public void setMiembros(List<MiembroTripulacionDTO> miembros) {
        this.miembros = miembros;
    }
    
    public List<PirataDTO> getPiratasDisponibles() {
        return piratasDisponibles;
    }
    
    public void setPiratasDisponibles(List<PirataDTO> piratasDisponibles) {
        this.piratasDisponibles = piratasDisponibles;
    }
}
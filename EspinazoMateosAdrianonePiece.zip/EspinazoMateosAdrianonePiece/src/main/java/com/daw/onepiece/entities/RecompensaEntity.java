package com.daw.onepiece.entities;

import java.math.BigDecimal;

import jakarta.persistence.*;

@Entity
@Table(name = "Recompensa") 
public class RecompensaEntity {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "pirata_id", referencedColumnName = "id")
    private PirataEntity pirata;

    @Column(name = "cantidad")
    private BigDecimal cantidad; // DEBE ser Integer

    @Column(name = "`estaVigente`") 
    private Boolean estaVigente;

    public RecompensaEntity() {
    }

    public RecompensaEntity(Integer id, PirataEntity pirata, BigDecimal cantidad, Boolean estaVigente) {
        this.id = id;
        this.pirata = pirata;
        this.cantidad = cantidad;
        this.estaVigente = estaVigente;
    }

    // Getters y setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public PirataEntity getPirata() {
        return pirata;
    }

    public void setPirata(PirataEntity pirata) {
        this.pirata = pirata;
    }

    public BigDecimal getCantidad() {
        return cantidad;
    }

    public void setCantidad(BigDecimal cantidad) {
        this.cantidad = cantidad;
    }

    public Boolean getEstaVigente() {
        return estaVigente;
    }

    public void setEstaVigente(Boolean estaVigente) {
        this.estaVigente = estaVigente;
    }
}
package com.daw.onepiece.servicio.impl;

import com.daw.onepiece.dao.interfaces.IIslaDAO;
import com.daw.onepiece.dtos.IslaDTO;
import com.daw.onepiece.servicio.interfaces.IIslaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IslaServiceImpl implements IIslaService {

    @Autowired
    private IIslaDAO islaDAO;

    @Override
    public List<IslaDTO> obtenerTodasIslas() {
        return islaDAO.obtenerTodasIslas();
    }
}
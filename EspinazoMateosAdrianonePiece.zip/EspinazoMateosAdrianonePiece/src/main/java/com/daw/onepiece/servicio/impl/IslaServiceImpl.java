package com.daw.onepiece.servicio.impl;

import com.daw.onepiece.dtos.IslaDTO;
import com.daw.onepiece.repositorios.IIslaRepository;
import com.daw.onepiece.servicio.interfaces.IIslaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class IslaServiceImpl implements IIslaService {
    
    @Autowired
    private IIslaRepository islaRepository;
    
   
    public IslaServiceImpl() {
        
    }
    
    @Override
    public List<IslaDTO> obtenerTodasIslas() {
        return islaRepository.findAll().stream()
                .map(isla -> new IslaDTO(isla.getId(), isla.getNombre()))
                .collect(Collectors.toList());
    }
    
   
}
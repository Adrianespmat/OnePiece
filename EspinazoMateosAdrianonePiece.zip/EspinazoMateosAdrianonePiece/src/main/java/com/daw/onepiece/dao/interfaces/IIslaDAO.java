package com.daw.onepiece.dao.interfaces;

import com.daw.onepiece.dtos.IslaDTO;
import java.util.List;

public interface IIslaDAO {
    List<IslaDTO> obtenerTodasLasIslas();
    IslaDTO obtenerIslaPorId(Integer id);
    IslaDTO obtenerIslaPorNombre(String nombre);
}
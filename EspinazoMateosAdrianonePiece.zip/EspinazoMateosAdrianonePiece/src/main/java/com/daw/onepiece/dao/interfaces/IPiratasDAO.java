package com.daw.onepiece.dao.interfaces;

import com.daw.onepiece.dtos.PirataDTO;
import java.util.ArrayList;


public interface IPiratasDAO {
    ArrayList<PirataDTO> buscarPiratasConFiltros(Integer id, String nombre, String frutadeldiablo, Boolean esta_Activo);
    Integer crearPirata(PirataDTO pirataDTO);
    Integer actualizarPirata(PirataDTO pirataDTO);
    void eliminarPirata(Integer id);
    PirataDTO obtenerPirataPorId(Integer id);
}
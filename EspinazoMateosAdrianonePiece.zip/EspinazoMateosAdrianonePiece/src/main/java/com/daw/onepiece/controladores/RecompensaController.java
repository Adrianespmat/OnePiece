package com.daw.onepiece.controladores;

import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.servicio.interfaces.IRecompensaService;
import com.daw.onepiece.servicio.interfaces.IPiratasService; // Usa tu interfaz existente
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/recompensas")
public class RecompensaController {

    @Autowired
    private IRecompensaService recompensaService;
    
    @Autowired
    private IPiratasService piratasService; // Cambiado a IPiratasService

    // ========== LISTAR RECOMPENSAS ==========
    @GetMapping("/listadoRecompensas")
    public String mostrarFormularioListado(Model model) {
        System.out.println("✅ GET /recompensas/listadoRecompensas");
        
        List<TripulacionDTO> tripulacionesActivas = recompensaService.obtenerTripulacionesActivas();
        model.addAttribute("lista", new ArrayList<RecompensaDTO>());
        model.addAttribute("tripulacionesActivas", tripulacionesActivas != null ? tripulacionesActivas : new ArrayList<>());
        return "recompensas/listadoRecompensas";
    }

    @PostMapping("/listadoRecompensas")
    public String buscarRecompensas(
            @RequestParam(required = false) String nombrePirata,
            @RequestParam(required = false) String idTripulacion,
            @RequestParam(required = false) String cantidad,
            @RequestParam(required = false, defaultValue = "1") String estaVigente,
            Model model) {
        
        System.out.println("✅ POST /recompensas/listadoRecompensas");
        
        Integer idTripulacionFiltro = null;
        if (idTripulacion != null && !idTripulacion.trim().isEmpty()) {
            try {
                idTripulacionFiltro = Integer.parseInt(idTripulacion);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ ID Tripulación no válido: " + idTripulacion);
            }
        }
        
        Integer cantidadFiltro = null;
        if (cantidad != null && !cantidad.trim().isEmpty()) {
            try {
                cantidadFiltro = Integer.parseInt(cantidad);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ Cantidad no válida: " + cantidad);
            }
        }
        
        Boolean vigenteFiltro = "1".equals(estaVigente) ? true : null;
        
        List<RecompensaDTO> listaFiltrada = recompensaService.obtenerRecompensasConFiltros(
            nombrePirata, idTripulacionFiltro, cantidadFiltro, vigenteFiltro);
        
        List<TripulacionDTO> tripulacionesActivas = recompensaService.obtenerTripulacionesActivas();
        
        model.addAttribute("lista", listaFiltrada != null ? listaFiltrada : new ArrayList<>());
        model.addAttribute("tripulacionesActivas", tripulacionesActivas != null ? tripulacionesActivas : new ArrayList<>());
        System.out.println("✅ Encontradas " + listaFiltrada.size() + " recompensas");
        
        return "recompensas/listadoRecompensas";
    }

    // ========== EMITIR RECOMPENSA ==========
    @GetMapping("/emitirRecompensa")
    public String mostrarFormularioEmitir(Model model) {
        System.out.println("✅ GET /recompensas/emitirRecompensa");
        
        // Usa el método TodosLosPiratas() y filtra los activos
        List<PirataDTO> todosPiratas = piratasService.TodosLosPiratas();
        List<PirataDTO> piratasActivos = new ArrayList<>();
        
        if (todosPiratas != null) {
            for (PirataDTO pirata : todosPiratas) {
                if (pirata.getEstaActivo() != null && pirata.getEstaActivo()) {
                    piratasActivos.add(pirata);
                }
            }
        }
        
        model.addAttribute("resultado", 0);
        model.addAttribute("piratasActivos", piratasActivos);
        return "recompensas/emitirRecompensa";
    }

    @PostMapping("/emitirRecompensa")
    public String emitirRecompensa(
            @RequestParam Integer idPirata,
            @RequestParam BigDecimal cantidad, // Ya es BigDecimal
            Model model) {
        
        System.out.println("✅ POST /recompensas/emitirRecompensa");
        System.out.println("  Pirata: " + idPirata);
        System.out.println("  Cantidad: " + cantidad);
        
        Integer resultado = 0;
        
        try {
            // Usar compareTo() para BigDecimal
            if (cantidad.compareTo(BigDecimal.ZERO) <= 0) {
                model.addAttribute("error", "La cantidad debe ser mayor que 0");
                
                // Recargar piratas activos
                List<PirataDTO> todosPiratas = piratasService.TodosLosPiratas();
                List<PirataDTO> piratasActivos = new ArrayList<>();
                
                if (todosPiratas != null) {
                    for (PirataDTO pirata : todosPiratas) {
                        if (pirata.getEstaActivo() != null && pirata.getEstaActivo()) {
                            piratasActivos.add(pirata);
                        }
                    }
                }
                
                model.addAttribute("piratasActivos", piratasActivos);
                return "recompensas/emitirRecompensa"; // Asegúrate que sea el nombre correcto
            }
            
            // ❌ ELIMINAR ESTO: cantidad YA ES BigDecimal
            // BigDecimal cantidadBD = BigDecimal.valueOf(cantidad);
            
            // ✅ Pasar directamente cantidad (ya es BigDecimal)
            resultado = recompensaService.emitirRecompensa(idPirata, cantidad);
            
            if (resultado != null && resultado > 0) {
                model.addAttribute("resultado", resultado);
                model.addAttribute("mensaje", "Recompensa emitida correctamente");
            } else {
                model.addAttribute("error", "Error al emitir recompensa");
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error al emitir recompensa: " + e.getMessage());
            model.addAttribute("error", "Error al emitir recompensa: " + e.getMessage());
            
            // Recargar piratas activos
            List<PirataDTO> todosPiratas = piratasService.TodosLosPiratas();
            List<PirataDTO> piratasActivos = new ArrayList<>();
            
            if (todosPiratas != null) {
                for (PirataDTO pirata : todosPiratas) {
                    if (pirata.getEstaActivo() != null && pirata.getEstaActivo()) {
                        piratasActivos.add(pirata);
                    }
                }
            }
            
            model.addAttribute("piratasActivos", piratasActivos);
            return "recompensas/emitirRecompensa"; // Asegúrate que sea el nombre correcto
        }
        
        return "redirect:/recompensas/emitirRecompensa?success=true&id=" + resultado;
    }

    // ========== ACTUALIZAR RECOMPENSA ==========
    @GetMapping("/formularioActualizarRecompensas")
    public String mostrarBusquedaActualizar(Model model) {
        System.out.println("✅ GET /recompensas/formularioActualizarRecompensas");
        
        // Usa el método TodosLosPiratas() y filtra los activos
        List<PirataDTO> todosPiratas = piratasService.TodosLosPiratas();
        List<PirataDTO> piratasActivos = new ArrayList<>();
        
        if (todosPiratas != null) {
            for (PirataDTO pirata : todosPiratas) {
                if (pirata.getEstaActivo() != null && pirata.getEstaActivo()) {
                    piratasActivos.add(pirata);
                }
            }
        }
        
        model.addAttribute("lista", new ArrayList<RecompensaDTO>());
        model.addAttribute("resultado", 0);
        model.addAttribute("piratasActivos", piratasActivos);
        return "recompensas/actualizarRecompensas";
    }
    
    @PostMapping("/formularioActualizarRecompensas")
    public String buscarParaActualizar(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String nombrePirata,
            @RequestParam(required = false, defaultValue = "1") String estaVigente,
            Model model) {
        
        System.out.println("✅ POST /recompensas/formularioActualizarRecompensas");
        
        // Obtenemos todas las recompensas y filtramos localmente
        List<RecompensaDTO> todasRecompensas = recompensaService.obtenerRecompensasConFiltros(
            null, null, null, null);
        if (todasRecompensas == null) {
            todasRecompensas = new ArrayList<>();
        }
        
        List<RecompensaDTO> listaFiltrada = new ArrayList<>();
        Integer idFiltro = null;
        
        if (id != null && !id.trim().isEmpty()) {
            try {
                idFiltro = Integer.parseInt(id);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ ID no válido: " + id);
            }
        }
        
        Boolean vigenteFiltro = "1".equals(estaVigente);
        
        for (RecompensaDTO recompensa : todasRecompensas) {
            boolean pasaFiltro = true;
            
            if (idFiltro != null && !recompensa.getId().equals(idFiltro)) {
                pasaFiltro = false;
            }
            
            if (nombrePirata != null && !nombrePirata.trim().isEmpty() && 
                (recompensa.getNombrePirata() == null || 
                 !recompensa.getNombrePirata().toLowerCase().contains(nombrePirata.toLowerCase()))) {
                pasaFiltro = false;
            }
            
            if (vigenteFiltro && (recompensa.getEstaVigente() == null || recompensa.getEstaVigente() != 1)) {
                pasaFiltro = false;
            }
            
            if (pasaFiltro) {
                listaFiltrada.add(recompensa);
            }
        }
        
        // Cargar piratas activos
        List<PirataDTO> todosPiratas = piratasService.TodosLosPiratas();
        List<PirataDTO> piratasActivos = new ArrayList<>();
        
        if (todosPiratas != null) {
            for (PirataDTO pirata : todosPiratas) {
                if (pirata.getEstaActivo() != null && pirata.getEstaActivo()) {
                    piratasActivos.add(pirata);
                }
            }
        }
        
        model.addAttribute("lista", listaFiltrada);
        model.addAttribute("resultado", 0);
        model.addAttribute("piratasActivos", piratasActivos);
        
        System.out.println("✅ Encontradas " + listaFiltrada.size() + " recompensas para actualizar");
        
        return "recompensas/actualizarRecompensas";
    }

    @PostMapping("/actualizarRecompensa")
    public String editarRecompensa(
            @RequestParam Integer id,
            @RequestParam(required = false) Integer idPirata,
            @RequestParam(required = false) BigDecimal cantidad,
            @RequestParam(required = false, defaultValue = "1") String estaVigente,
            Model model) {
        
        System.out.println("✅ POST /recompensas/actualizarRecompensa");
        System.out.println("  ID: " + id);
        System.out.println("  Pirata: " + idPirata);
        System.out.println("  Cantidad: " + cantidad);
        System.out.println("  Vigente: " + estaVigente);
        
        Integer resultado = 0;
        
        try {
            Boolean vigente = "1".equals(estaVigente);
            
            resultado = recompensaService.actualizarRecompensa(id, idPirata, cantidad, vigente);
            
            if (resultado != null && resultado > 0) {
                model.addAttribute("resultado", resultado);
                model.addAttribute("mensaje", "Recompensa actualizada correctamente");
            } else {
                model.addAttribute("error", "Error al actualizar recompensa");
            }
            
        } catch (Exception e) {
            System.out.println("❌ Error al editar recompensa: " + e.getMessage());
            model.addAttribute("error", "Error al actualizar recompensa");
        }
        
        return "redirect:/recompensas/formularioActualizarRecompensas?success=true&id=" + resultado;
    }

    // ========== ELIMINAR RECOMPENSA ==========
    @GetMapping("/formularioBorrarRecompensas")
    public String mostrarBusquedaEliminar(Model model) {
        System.out.println("✅ GET /recompensas/formularioBorrarRecompensas");
        
        model.addAttribute("lista", new ArrayList<RecompensaDTO>());
        model.addAttribute("resultado", 0);
        return "recompensas/borrarRecompensas";
    }
    
    @PostMapping("/formularioBorrarRecompensas")
    public String buscarParaEliminar(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String nombrePirata,
            Model model) {
        
        System.out.println("✅ POST /recompensas/formularioBorrarRecompensas");
        
        // Obtenemos solo recompensas vigentes para eliminar
        List<RecompensaDTO> recompensasVigentes = recompensaService.obtenerRecompensasConFiltros(
            null, null, null, true);
        if (recompensasVigentes == null) {
            recompensasVigentes = new ArrayList<>();
        }
        
        List<RecompensaDTO> listaFiltrada = new ArrayList<>();
        Integer idFiltro = null;
        
        if (id != null && !id.trim().isEmpty()) {
            try {
                idFiltro = Integer.parseInt(id);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ ID no válido: " + id);
            }
        }
        
        for (RecompensaDTO recompensa : recompensasVigentes) {
            boolean pasaFiltro = true;
            
            if (idFiltro != null && !recompensa.getId().equals(idFiltro)) {
                pasaFiltro = false;
            }
            
            if (nombrePirata != null && !nombrePirata.trim().isEmpty() && 
                (recompensa.getNombrePirata() == null || 
                 !recompensa.getNombrePirata().toLowerCase().contains(nombrePirata.toLowerCase()))) {
                pasaFiltro = false;
            }
            
            if (pasaFiltro) {
                listaFiltrada.add(recompensa);
            }
        }
        
        model.addAttribute("lista", listaFiltrada);
        model.addAttribute("resultado", 0);
        
        System.out.println("✅ Encontradas " + listaFiltrada.size() + " recompensas para eliminar");
        
        return "recompensas/borrarRecompensas";
    }

    @PostMapping("/borrarRecompensa")
    public String eliminarRecompensa(@RequestParam Integer id, Model model) {
        System.out.println("✅ POST /recompensas/borrarRecompensa?id=" + id);
        
        Integer resultado = 0;
        
        try {
            recompensaService.eliminarRecompensa(id);
            resultado = id;
            model.addAttribute("resultado", resultado);
            model.addAttribute("mensaje", "Recompensa eliminada (marcada como no vigente) correctamente");
        } catch (Exception e) {
            System.out.println("❌ Error al eliminar recompensa: " + e.getMessage());
            model.addAttribute("resultado", 0);
            model.addAttribute("mensaje", "Error al eliminar recompensa");
        }
        
        model.addAttribute("lista", new ArrayList<RecompensaDTO>());
        return "recompensas/borrarRecompensas";
    }
}
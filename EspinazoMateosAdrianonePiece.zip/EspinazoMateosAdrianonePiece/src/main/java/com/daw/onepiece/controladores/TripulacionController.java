package com.daw.onepiece.controladores;

import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.dtos.DetalleTripulacionDTO;
import com.daw.onepiece.dtos.MiembroTripulacionDTO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.servicio.interfaces.ITripulacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/tripulaciones")
public class TripulacionController {

    @Autowired
    private ITripulacionService tripulacionService;

    // ========== LISTAR TRIPULACIONES ==========
    @GetMapping("/listadoTripulaciones")
    public String mostrarFormularioListado(Model model) {
        System.out.println("✅ GET /tripulaciones/listadoTripulaciones");
        
        model.addAttribute("lista", new ArrayList<TripulacionDTO>());
        return "tripulaciones/listadoTripulaciones";
    }

    @PostMapping("/listadoTripulaciones")
    public String buscarTripulaciones(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String barco,
            @RequestParam(required = false, defaultValue = "1") String estaActiva,
            Model model) {
        
        System.out.println("✅ POST /tripulaciones/listadoTripulaciones");
        
        List<TripulacionDTO> todasTripulaciones = tripulacionService.obtenerTodasTripulaciones();
        if (todasTripulaciones == null) {
            todasTripulaciones = new ArrayList<>();
        }
        
        List<TripulacionDTO> listaFiltrada = new ArrayList<>();
        Integer idFiltro = null;
        
        if (id != null && !id.trim().isEmpty()) {
            try {
                idFiltro = Integer.parseInt(id);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ ID no válido: " + id);
            }
        }
        
        Boolean activaFiltro = "1".equals(estaActiva);
        
        for (TripulacionDTO tripulacion : todasTripulaciones) {
            boolean pasaFiltro = true;
            
            if (idFiltro != null && !tripulacion.getId().equals(idFiltro)) {
                pasaFiltro = false;
            }
            
            if (nombre != null && !nombre.trim().isEmpty() && 
                (tripulacion.getNombre() == null || 
                 !tripulacion.getNombre().toLowerCase().contains(nombre.toLowerCase()))) {
                pasaFiltro = false;
            }
            
            if (barco != null && !barco.trim().isEmpty() && 
                (tripulacion.getBarco() == null || 
                 !tripulacion.getBarco().toLowerCase().contains(barco.toLowerCase()))) {
                pasaFiltro = false;
            }
            
            if (activaFiltro && (tripulacion.getEstaActiva() == null || !tripulacion.getEstaActiva())) {
                pasaFiltro = false;
            }
            
            if (pasaFiltro) {
                listaFiltrada.add(tripulacion);
            }
        }
        
        model.addAttribute("lista", listaFiltrada);
        System.out.println("✅ Encontradas " + listaFiltrada.size() + " tripulaciones");
        
        return "tripulaciones/listadoTripulaciones";
    }

    // ========== VER DETALLES DE TRIPULACIÓN ==========
    @GetMapping("/detallesTripulacion")
    public String verDetallesTripulacion(@RequestParam Integer id, Model model) {
        System.out.println("🔍 GET detallesTripulacion para ID: " + id);
        
    
            DetalleTripulacionDTO detalle = tripulacionService.obtenerDetalleTripulacion(id);
            
            if (detalle == null) {
                System.out.println("❌ No se encontró la tripulación con ID: " + id);
                return "redirect:/tripulaciones/listadoTripulaciones?error=Tripulacion+no+encontrada";
            }
            List<PirataDTO> piratasDisponibles = tripulacionService.obtenerPiratasDisponibles();
            
            // ✅ Pasa los datos directamente
            model.addAttribute("tripulacion", detalle.getTripulacion());
            model.addAttribute("miembros", detalle.getMiembros() != null ? detalle.getMiembros() : new ArrayList<>());
            model.addAttribute("piratasActivos", piratasDisponibles != null ? piratasDisponibles : new ArrayList<>());
            
            System.out.println("✅ Datos cargados correctamente para tripulación ID: " + id);
            return "tripulaciones/detallesTripulacion";
            
   
    }

    // ========== AÑADIR MIEMBRO ==========
    @PostMapping("/agregarMiembro")
    public String agregarMiembro(
            @RequestParam Integer idTripulacion,
            @RequestParam Integer idPirata,
            @RequestParam String rol,
            Model model) {
        
        System.out.println("✅ POST /tripulaciones/agregarMiembro");
        System.out.println("  Tripulación: " + idTripulacion);
        System.out.println("  Pirata: " + idPirata);
        System.out.println("  Rol: " + rol);
        
        try {
            tripulacionService.agregarMiembro(idTripulacion, idPirata, rol);
            model.addAttribute("resultado", 1);
            model.addAttribute("mensaje", "Miembro añadido correctamente");
        } catch (Exception e) {
            System.out.println("❌ Error al añadir miembro: " + e.getMessage());
            model.addAttribute("resultado", 0);
            model.addAttribute("mensaje", "Error al añadir miembro");
        }
        
        return "redirect:/tripulaciones/detallesTripulacion?id=" + idTripulacion;
    }

    // ========== ELIMINAR MIEMBRO ==========
    @PostMapping("/eliminarMiembro")
    public String eliminarMiembro(
            @RequestParam Integer idTripulacion,
            @RequestParam Integer idPirata,
            Model model) {
        
        System.out.println("✅ POST /tripulaciones/eliminarMiembro");
        System.out.println("  Tripulación: " + idTripulacion);
        System.out.println("  Pirata: " + idPirata);
        
        try {
            DetalleTripulacionDTO detalle = tripulacionService.obtenerDetalleTripulacion(idTripulacion);
            Integer reclutamientoId = null;
            
            if (detalle != null && detalle.getMiembros() != null) {
                for (MiembroTripulacionDTO miembro : detalle.getMiembros()) {
                    if (miembro.getPirataId().equals(idPirata)) {
                        reclutamientoId = miembro.getReclutamientoId();
                        break;
                    }
                }
            }
            
            if (reclutamientoId != null) {
                tripulacionService.eliminarMiembro(reclutamientoId);
                model.addAttribute("resultado", 1);
                model.addAttribute("mensaje", "Miembro eliminado correctamente");
            } else {
                model.addAttribute("resultado", 0);
                model.addAttribute("mensaje", "No se encontró al miembro en la tripulación");
            }
        } catch (Exception e) {
            System.out.println("❌ Error al eliminar miembro: " + e.getMessage());
            model.addAttribute("resultado", 0);
            model.addAttribute("mensaje", "Error al eliminar miembro");
        }
        
        return "redirect:/tripulaciones/detallesTripulacion?id=" + idTripulacion;
    }

    // ========== CREAR TRIPULACIÓN ==========
    @GetMapping("/insertarTripulacion")
    public String mostrarFormularioCrear(Model model) {
        System.out.println("✅ GET /tripulaciones/insertarTripulacion");
        
        model.addAttribute("resultado", 0);
        return "tripulaciones/insertarTripulacion";
    }

    @PostMapping("/insertarTripulacion")
    public String crearTripulacion(
            @RequestParam String nombre,
            @RequestParam String barco,
            @RequestParam(required = false, defaultValue = "1") String estaActiva,
            Model model) {
        
        System.out.println("✅ POST /tripulaciones/insertarTripulacion");
        System.out.println("  Nombre: " + nombre);
        System.out.println("  Barco: " + barco);
        System.out.println("  Activa: " + estaActiva);
        
        Integer resultado = 0;
        
        try {
            TripulacionDTO tripulacionDTO = new TripulacionDTO();
            tripulacionDTO.setNombre(nombre.trim());
            tripulacionDTO.setBarco(barco.trim());
            tripulacionDTO.setActiva("1".equals(estaActiva) ? 1 : 0);
            
            resultado = tripulacionService.crearTripulacion(tripulacionDTO);
            
            model.addAttribute("resultado", resultado != null && resultado > 0 ? resultado : 0);
            
        } catch (Exception e) {
            System.out.println("❌ Error al crear tripulación: " + e.getMessage());
            model.addAttribute("resultado", 0);
        }
        
        return "tripulaciones/insertarTripulacion";
    }

    // ========== ACTUALIZAR TRIPULACIÓN ==========
    @GetMapping("/formularioActualizarTripulaciones")
    public String mostrarBusquedaActualizar(Model model) {
        System.out.println("✅ GET /tripulaciones/formularioActualizarTripulaciones");
        
        model.addAttribute("lista", new ArrayList<TripulacionDTO>());
        model.addAttribute("resultado", 0);
        return "tripulaciones/actualizarTripulaciones";
    }
    
    @PostMapping("/formularioActualizarTripulaciones")
    public String buscarParaActualizar(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false, defaultValue = "1") String estaActiva,
            Model model) {
        
        System.out.println("✅ POST /tripulaciones/formularioActualizarTripulaciones");
        
        List<TripulacionDTO> todasTripulaciones = tripulacionService.obtenerTodasTripulaciones();
        if (todasTripulaciones == null) {
            todasTripulaciones = new ArrayList<>();
        }
        
        List<TripulacionDTO> listaFiltrada = new ArrayList<>();
        Integer idFiltro = null;
        
        if (id != null && !id.trim().isEmpty()) {
            try {
                idFiltro = Integer.parseInt(id);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ ID no válido: " + id);
            }
        }
        
        Boolean activaFiltro = "1".equals(estaActiva);
        
        for (TripulacionDTO tripulacion : todasTripulaciones) {
            boolean pasaFiltro = true;
            
            if (idFiltro != null && !tripulacion.getId().equals(idFiltro)) {
                pasaFiltro = false;
            }
            
            if (nombre != null && !nombre.trim().isEmpty() && 
                (tripulacion.getNombre() == null || 
                 !tripulacion.getNombre().toLowerCase().contains(nombre.toLowerCase()))) {
                pasaFiltro = false;
            }
            
            if (activaFiltro && (tripulacion.getEstaActiva() == null || !tripulacion.getEstaActiva())) {
                pasaFiltro = false;
            }
            
            if (pasaFiltro) {
                listaFiltrada.add(tripulacion);
            }
        }
        
        model.addAttribute("lista", listaFiltrada);
        model.addAttribute("resultado", 0);
        
        System.out.println("✅ Encontradas " + listaFiltrada.size() + " tripulaciones para actualizar");
        
        return "tripulaciones/actualizarTripulaciones";
    }

    @PostMapping("/actualizarTripulacion")
    public String editarTripulacion(
            @RequestParam Integer id,
            @RequestParam String nombre,
            @RequestParam String barco,
            @RequestParam(required = false, defaultValue = "1") String estaActiva,
            Model model) {
        
        System.out.println("✅ POST /tripulaciones/actualizarTripulacion");
        System.out.println("  ID: " + id);
        System.out.println("  Nombre: " + nombre);
        System.out.println("  Barco: " + barco);
        System.out.println("  Activa: " + estaActiva);
        
        Integer resultado = 0;
        
        try {
            TripulacionDTO tripulacionDTO = new TripulacionDTO();
            tripulacionDTO.setId(id);
            tripulacionDTO.setNombre(nombre.trim());
            tripulacionDTO.setBarco(barco.trim());
            tripulacionDTO.setActiva("1".equals(estaActiva) ? 1 : 0);
            
            resultado = tripulacionService.actualizarTripulacion(tripulacionDTO);
            
            List<TripulacionDTO> listaActualizada = new ArrayList<>();
            if (resultado != null && resultado > 0) {
                TripulacionDTO tripulacionActualizada = new TripulacionDTO();
                tripulacionActualizada.setId(id);
                tripulacionActualizada.setNombre(nombre.trim());
                tripulacionActualizada.setBarco(barco.trim());
                tripulacionActualizada.setActiva("1".equals(estaActiva) ? 1 : 0);
                listaActualizada.add(tripulacionActualizada);
                
                model.addAttribute("resultado", resultado);
            } else {
                model.addAttribute("resultado", 0);
            }
            
            model.addAttribute("lista", listaActualizada);
            
        } catch (Exception e) {
            System.out.println("❌ Error al editar tripulación: " + e.getMessage());
            model.addAttribute("resultado", 0);
            model.addAttribute("lista", new ArrayList<TripulacionDTO>());
        }
        
        return "tripulaciones/actualizarTripulaciones";
    }

    // ========== ELIMINAR TRIPULACIÓN ==========
    @GetMapping("/formularioBorrarTripulaciones")
    public String mostrarBusquedaEliminar(Model model) {
        System.out.println("✅ GET /tripulaciones/borrarTripulaciones");
        
        model.addAttribute("lista", new ArrayList<TripulacionDTO>());
        model.addAttribute("resultado", 0);
        return "tripulaciones/borrarTripulaciones";
    }
    
    @PostMapping("/formularioBorrarTripulaciones")
    public String buscarParaEliminar(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String nombre,
            Model model) {
        
        System.out.println("✅ POST /tripulaciones/formularioBorrarTripulaciones");
        
        List<TripulacionDTO> todasTripulaciones = tripulacionService.obtenerTodasTripulaciones();
        if (todasTripulaciones == null) {
            todasTripulaciones = new ArrayList<>();
        }
        
        List<TripulacionDTO> listaFiltrada = new ArrayList<>();
        Integer idFiltro = null;
        
        if (id != null && !id.trim().isEmpty()) {
            try {
                idFiltro = Integer.parseInt(id);
            } catch (NumberFormatException e) {
                System.out.println("⚠️ ID no válido: " + id);
            }
        }
        
        for (TripulacionDTO tripulacion : todasTripulaciones) {
            boolean pasaFiltro = true;
            
            if (tripulacion.getEstaActiva() == null || !tripulacion.getEstaActiva()) {
                pasaFiltro = false;
            }
            
            if (idFiltro != null && !tripulacion.getId().equals(idFiltro)) {
                pasaFiltro = false;
            }
            
            if (nombre != null && !nombre.trim().isEmpty() && 
                (tripulacion.getNombre() == null || 
                 !tripulacion.getNombre().toLowerCase().contains(nombre.toLowerCase()))) {
                pasaFiltro = false;
            }
            
            if (pasaFiltro) {
                listaFiltrada.add(tripulacion);
            }
        }
        
        model.addAttribute("lista", listaFiltrada);
        model.addAttribute("resultado", 0);
        
        System.out.println("✅ Encontradas " + listaFiltrada.size() + " tripulaciones para eliminar");
        
        return "tripulaciones/borrarTripulaciones";
    }

    @PostMapping("/borrarTripulacion")
    public String eliminarTripulacion(@RequestParam Integer id, Model model) {
        System.out.println("✅ POST /tripulaciones/borrarTripulacion?id=" + id);
        
        Integer resultado = 0;
        
        try {
            tripulacionService.eliminarTripulacion(id);
            resultado = id;
            model.addAttribute("resultado", resultado);
            model.addAttribute("mensaje", "Tripulación eliminada correctamente");
        } catch (Exception e) {
            System.out.println("❌ Error al eliminar tripulación: " + e.getMessage());
            model.addAttribute("resultado", 0);
            model.addAttribute("mensaje", "Error al eliminar tripulación");
        }
        
        model.addAttribute("lista", new ArrayList<TripulacionDTO>());
        return "tripulaciones/borrarTripulaciones";
    }

    // ========== MÉTODO DE PRUEBA ==========
    @GetMapping("/test")
    @ResponseBody
    public String test() {
        return "✅ Controller de Tripulaciones funciona correctamente!";
    }
}
package com.daw.onepiece.dtos;

import java.math.BigDecimal;

public class RecompensaDTO {
    private Integer id;
    private Integer idPirata;
    private String nombrePirata;
    private BigDecimal cantidad; // Integer para compatibilidad con vistas
    private Integer estaVigente;
    private String tripulacion;
    
    public RecompensaDTO() {
    }
    
    public RecompensaDTO(Integer id, Integer idPirata, String nombrePirata, 
    		BigDecimal cantidad, Integer estaVigente, String tripulacion) {
        this.id = id;
        this.idPirata = idPirata;
        this.nombrePirata = nombrePirata;
        this.cantidad = cantidad;
        this.estaVigente = estaVigente;
        this.tripulacion = tripulacion;
    }
    
    // Getters y Setters
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getIdPirata() {
        return idPirata;
    }
    
    public void setIdPirata(Integer idPirata) {
        this.idPirata = idPirata;
    }
    
    public String getNombrePirata() {
        return nombrePirata;
    }
    
    public void setNombrePirata(String nombrePirata) {
        this.nombrePirata = nombrePirata;
    }
    
    public BigDecimal getCantidad() {
        return cantidad;
    }
    
    public void setCantidad(BigDecimal cantidad) {
        this.cantidad = cantidad;
    }
    
    public Integer getEstaVigente() {
        return estaVigente;
    }
    
    public void setEstaVigente(Integer estaVigente) {
        this.estaVigente = estaVigente;
    }
    
    public String getTripulacion() {
        return tripulacion;
    }
    
    public void setTripulacion(String tripulacion) {
        this.tripulacion = tripulacion;
    }
    
    public Boolean getVigente() {
        return estaVigente != null && estaVigente == 1;
    }
    
    public void setVigente(Boolean vigente) {
        this.estaVigente = vigente != null && vigente ? 1 : 0;
    }
}
package com.daw.onepiece.dtos;

public class MiembroTripulacionDTO {
    private Integer reclutamientoId;
    private Integer pirataId;
    private String pirataNombre;
    private String rol;
    private Boolean esMiembroActual;
    
    
    private Integer id;          
    private String nombre;        
    private String frutaDiablo;   
    
    public MiembroTripulacionDTO() {
    }
    
    // Modifica el constructor para inicializar los nuevos campos
    public MiembroTripulacionDTO(Integer reclutamientoId, Integer pirataId, String pirataNombre, 
                                 String rol, Boolean esMiembroActual) {
        this.reclutamientoId = reclutamientoId;
        this.pirataId = pirataId;
        this.pirataNombre = pirataNombre;
        this.rol = rol;
        this.esMiembroActual = esMiembroActual;
        
        // Inicializa los campos que el HTML espera
        this.id = pirataId;           // id apunta a pirataId
        this.nombre = pirataNombre;   // nombre apunta a pirataNombre
        this.frutaDiablo = null;      // O algún valor por defecto
    }
    
    // Getters y Setters existentes...
    public Integer getReclutamientoId() {
        return reclutamientoId;
    }
    
    public void setReclutamientoId(Integer reclutamientoId) {
        this.reclutamientoId = reclutamientoId;
    }
    
    public Integer getPirataId() {
        return pirataId;
    }
    
    public void setPirataId(Integer pirataId) {
        this.pirataId = pirataId;
        this.id = pirataId;  // Actualiza también id cuando cambie pirataId
    }
    
    public String getPirataNombre() {
        return pirataNombre;
    }
    
    public void setPirataNombre(String pirataNombre) {
        this.pirataNombre = pirataNombre;
        this.nombre = pirataNombre;  // Actualiza también nombre
    }
    
    public String getRol() {
        return rol;
    }
    
    public void setRol(String rol) {
        this.rol = rol;
    }
    
    public Boolean getEsMiembroActual() {
        return esMiembroActual;
    }
    
    public void setEsMiembroActual(Boolean esMiembroActual) {
        this.esMiembroActual = esMiembroActual;
    }
    
    // AÑADE ESTOS NUEVOS GETTERS para que el HTML funcione
    public Integer getId() {
        return id != null ? id : pirataId;  // Devuelve id o pirataId como fallback
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getNombre() {
        return nombre != null ? nombre : pirataNombre;  // Devuelve nombre o pirataNombre
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getFrutaDiablo() {
        return frutaDiablo != null ? frutaDiablo : "Sin fruta";  // Valor por defecto
    }
    
    public void setFrutaDiablo(String frutaDiablo) {
        this.frutaDiablo = frutaDiablo;
    }
    
    // Método para vistas
    public String getEstadoTexto() {
        return esMiembroActual != null && esMiembroActual ? "Activo" : "Inactivo";
    }
    
    public Integer getActivo() {
        return esMiembroActual != null && esMiembroActual ? 1 : 0;
    }
}
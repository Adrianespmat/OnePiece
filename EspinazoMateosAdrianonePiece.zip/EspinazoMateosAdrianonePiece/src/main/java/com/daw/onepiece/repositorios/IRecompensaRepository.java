package com.daw.onepiece.repositorios;

import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.entities.RecompensaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.transaction.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface IRecompensaRepository extends JpaRepository<RecompensaEntity, Integer> {
    
	@Query("SELECT new com.daw.onepiece.dtos.RecompensaDTO(" +
		       "r.id, r.pirata.id, p.nombre, r.cantidad, " +
		       "CASE WHEN r.estaVigente = true THEN 1 ELSE 0 END, " +
		       "COALESCE(t.nombre, 'Sin tripulación')) " + // ← Este es el 6º parámetro: la tripulación
		       "FROM RecompensaEntity r " +
		       "JOIN r.pirata p " +
		       "LEFT JOIN ReclutamientoEntity rec ON rec.pirata.id = p.id AND rec.esMiembroActual = true " +
		       "LEFT JOIN rec.tripulacion t " + // ← Aquí obtienes la tripulación
		       "WHERE " +
		       "(:nombrePirata IS NULL OR :nombrePirata = '' OR LOWER(p.nombre) LIKE LOWER(CONCAT('%', :nombrePirata, '%'))) AND " +
		       "(:idTripulacion IS NULL OR t.id = :idTripulacion) AND " +
		       "(:cantidadMinima IS NULL OR r.cantidad >= :cantidadMinima) AND " +
		       "(:soloVigentes IS NULL OR r.estaVigente = :soloVigentes) " +
		       "ORDER BY r.cantidad DESC")
		List<RecompensaDTO> findRecompensasConFiltros(
		        @Param("nombrePirata") String nombrePirata,
		        @Param("idTripulacion") Integer idTripulacion,
		        @Param("cantidadMinima") BigDecimal cantidadMinima,  // BigDecimal
		        @Param("soloVigentes") Boolean soloVigentes);
    
    @Query("SELECT r FROM RecompensaEntity r WHERE r.pirata.id = :idPirata AND r.estaVigente = true")
    RecompensaEntity findRecompensaVigenteByPirataId(@Param("idPirata") Integer idPirata);
    
    @Modifying
    @Transactional
    @Query("UPDATE RecompensaEntity r SET r.estaVigente = false WHERE r.id = :id")
    void marcarComoNoVigente(@Param("id") Integer id);
    
    @Modifying
    @Transactional
    @Query("UPDATE RecompensaEntity r SET r.estaVigente = false WHERE r.pirata.id = :idPirata AND r.estaVigente = true")
    void desactivarRecompensasVigentesDelPirata(@Param("idPirata") Integer idPirata);
}
package com.daw.onepiece.dao.impl;

import com.daw.onepiece.dao.interfaces.IRecompensaDAO;
import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.entities.RecompensaEntity;
import com.daw.onepiece.entities.PirataEntity;
import com.daw.onepiece.repositorios.IPiratasRepository;
import com.daw.onepiece.repositorios.IRecompensaRepository;
import com.daw.onepiece.repositorios.ITripulacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public class RecompensaDAOImpl implements IRecompensaDAO {

    @Autowired
    private IRecompensaRepository recompensaRepository;
    
    @Autowired
    private IPiratasRepository piratasRepository;
    
    @Autowired
    private ITripulacionRepository tripulacionRepository;

    @Override
    public List<RecompensaDTO> obtenerRecompensasConFiltros(String nombrePirata, Integer idTripulacion, 
                                                          BigDecimal cantidadMinima, Boolean soloVigentes) {
        try {
            List<RecompensaDTO> recompensas = recompensaRepository.findRecompensasConFiltros(
                nombrePirata, idTripulacion, cantidadMinima, soloVigentes);
            return recompensas != null ? recompensas : List.of();
        } catch (Exception e) {
            System.out.println("❌ Error en obtenerRecompensasConFiltros: " + e.getMessage());
            e.printStackTrace();
            return List.of();
        }
    }

    @Override
    public List<TripulacionDTO> obtenerTripulacionesActivas() {
        try {
            List<TripulacionDTO> tripulaciones = tripulacionRepository.findTripulacionesConFiltros(
                null, null, null, true);
            return tripulaciones != null ? tripulaciones : List.of();
        } catch (Exception e) {
            System.out.println("❌ Error en obtenerTripulacionesActivas: " + e.getMessage());
            e.printStackTrace();
            return List.of();
        }
    }

    @Override
    @Transactional
    public Integer emitirRecompensa(Integer idPirata, BigDecimal cantidad) {
        try {
            // Validar que la cantidad sea mayor que 0
            if (cantidad == null || cantidad.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("La cantidad debe ser mayor que 0");
            }
            
            // Verificar si el pirata tiene una recompensa vigente
            RecompensaEntity recompensaVigente = recompensaRepository.findRecompensaVigenteByPirataId(idPirata);
            if (recompensaVigente != null) {
                // Marcar la recompensa anterior como no vigente
                recompensaVigente.setEstaVigente(false);
                recompensaRepository.save(recompensaVigente);
                System.out.println("✅ Recompensa anterior ID " + recompensaVigente.getId() + " marcada como no vigente");
            }
            
            // Crear nueva recompensa
            Optional<PirataEntity> optionalPirata = piratasRepository.findById(idPirata);
            if (optionalPirata.isEmpty()) {
                throw new IllegalArgumentException("Pirata no encontrado");
            }
            
            RecompensaEntity nuevaRecompensa = new RecompensaEntity();
            nuevaRecompensa.setPirata(optionalPirata.get());
            nuevaRecompensa.setCantidad(cantidad);
            nuevaRecompensa.setEstaVigente(true);
            
            RecompensaEntity saved = recompensaRepository.save(nuevaRecompensa);
            
            System.out.println("✅ Recompensa emitida con ID: " + saved.getId());
            
            return saved.getId();
            
        } catch (Exception e) {
            System.out.println("❌ Error en emitirRecompensa: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    @Override
    @Transactional
    public Integer actualizarRecompensa(Integer id, Integer idPirata, BigDecimal cantidad, Boolean estaVigente) {
        try {
            Optional<RecompensaEntity> optional = recompensaRepository.findById(id);
            if (optional.isPresent()) {
                RecompensaEntity recompensa = optional.get();
                
                if (idPirata != null) {
                    Optional<PirataEntity> optionalPirata = piratasRepository.findById(idPirata);
                    optionalPirata.ifPresent(recompensa::setPirata);
                }
                
                if (cantidad != null) {
                    recompensa.setCantidad(cantidad); // BigDecimal
                }
                
                if (estaVigente != null) {
                    recompensa.setEstaVigente(estaVigente);
                }
                
                RecompensaEntity saved = recompensaRepository.save(recompensa);
                System.out.println("✅ Recompensa actualizada ID: " + saved.getId());
                return saved.getId();
            }
            return null;
        } catch (Exception e) {
            System.out.println("❌ Error en actualizarRecompensa: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    @Override
    @Transactional
    public void eliminarRecompensa(Integer id) {
        try {
            recompensaRepository.marcarComoNoVigente(id);
            System.out.println("✅ Recompensa ID " + id + " marcada como no vigente");
        } catch (Exception e) {
            System.out.println("❌ Error en eliminarRecompensa: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
package com.daw.onepiece.repositorios;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.daw.onepiece.dtos.MiembroTripulacionDTO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.entities.TripulacionEntity;

import jakarta.transaction.Transactional;

@Repository
public interface ITripulacionRepository extends JpaRepository<TripulacionEntity, Integer> {
    
	@Query("SELECT new com.daw.onepiece.dtos.TripulacionDTO(" +
		       "t.id, t.nombre, t.barco, t.estaActiva, " +
		       "CAST(COUNT(CASE WHEN r.esMiembroActual = true THEN 1 END) AS INTEGER)) " +  // ← CAST AS INTEGER
		       "FROM TripulacionEntity t " +
		       "LEFT JOIN t.reclutamientos r " +
		       "WHERE " +
		       "(:id IS NULL OR t.id = :id) AND " +
		       "(:nombre IS NULL OR :nombre = '' OR LOWER(t.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))) AND " +
		       "(:barco IS NULL OR :barco = '' OR LOWER(t.barco) LIKE LOWER(CONCAT('%', :barco, '%'))) AND " +
		       "(:soloActivas IS NULL OR t.estaActiva = :soloActivas) " +
		       "GROUP BY t.id, t.nombre, t.barco, t.estaActiva " +
		       "ORDER BY t.nombre")
		List<TripulacionDTO> findTripulacionesConFiltros(
		        @Param("id") Integer id,
		        @Param("nombre") String nombre,
		        @Param("barco") String barco,
		        @Param("soloActivas") Boolean soloActivas);
    
	@Query("SELECT new com.daw.onepiece.dtos.MiembroTripulacionDTO(" +
		       "r.id, p.id, p.nombre, r.rol, r.esMiembroActual) " +
		       "FROM ReclutamientoEntity r " +
		       "JOIN r.pirata p " +
		       "WHERE r.tripulacion.id = :tripulacionId " +
		       "AND r.esMiembroActual = true " +
		       "ORDER BY p.nombre")
		List<MiembroTripulacionDTO> findMiembrosByTripulacionId(@Param("tripulacionId") Integer tripulacionId);
    
    // ========== 3. OBTENER PIRATAS SIN TRIPULACIÓN (corregida) ==========
    @Query("SELECT new com.daw.onepiece.dtos.PirataDTO(" +
           "p.id, p.nombre, p.frutadeldiablo, p.fechaNacimiento, " +  // ← frutadeldiablo en minúsculas
           "p.esta_Activo, i.nombre, null, null) " +  // ← asegúrate que esto coincide con tu constructor PirataDTO
           "FROM PirataEntity p " +
           "LEFT JOIN p.isla i " +
           "WHERE p.esta_Activo = true " +
           "AND NOT EXISTS (" +
           "    SELECT 1 FROM ReclutamientoEntity r " +
           "    WHERE r.pirata = p AND r.esMiembroActual = true" +
           ") " +
           "ORDER BY p.nombre")
    List<PirataDTO> findPiratasSinTripulacion();
    
    @Query("SELECT new com.daw.onepiece.dtos.TripulacionDTO(" +
    	       "t.id, t.nombre, t.barco, t.estaActiva, " +
    	       "CAST(COUNT(CASE WHEN r.esMiembroActual = true THEN 1 END) AS INTEGER)) " +  // ← CAST AS INTEGER
    	       "FROM TripulacionEntity t " +
    	       "LEFT JOIN t.reclutamientos r " +
    	       "WHERE t.id = :id " +
    	       "GROUP BY t.id, t.nombre, t.barco, t.estaActiva")
    	TripulacionDTO findTripulacionByIdWithMemberCount(@Param("id") Integer id);
    
    // ========== 5. QUERY PARA DESACTIVAR RECLUTAMIENTOS (según PDF) ==========
    @Modifying
    @Transactional
    @Query("UPDATE ReclutamientoEntity r " +
           "SET r.esMiembroActual = false " +
           "WHERE r.pirata.id = :pirataId " +
           "AND r.esMiembroActual = true")
    void desactivarReclutamientosDelPirata(@Param("pirataId") Integer pirataId);
}
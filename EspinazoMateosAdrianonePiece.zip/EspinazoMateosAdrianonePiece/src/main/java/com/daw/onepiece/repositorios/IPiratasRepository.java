package com.daw.onepiece.repositorios;

import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.entities.PirataEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IPiratasRepository extends JpaRepository<PirataEntity, Integer> {

    
	@Query("SELECT new com.daw.onepiece.dtos.PirataDTO(" +
	           "p.id, p.nombre, p.frutadeldiablo, p.fechaNacimiento, " +
	           "p.esta_Activo, i.nombre, t.nombre, r.rol) " +
	           "FROM PirataEntity p " +
	           "LEFT JOIN p.isla i " +
	           "LEFT JOIN ReclutamientoEntity r ON r.pirata = p AND r.esMiembroActual = true " +
	           "LEFT JOIN r.tripulacion t " +
	           "WHERE (:id IS NULL OR p.id = :id) " +
	           "AND (:nombre IS NULL OR :nombre = '' OR LOWER(p.nombre) LIKE LOWER(CONCAT('%', :nombre, '%'))) " +
	           "AND (:frutadeldiablo IS NULL OR :frutadeldiablo = '' OR " +
	           "     LOWER(p.frutadeldiablo) LIKE LOWER(CONCAT('%', :frutadeldiablo, '%'))) " +
	           "AND (:esta_Activo IS NULL OR p.esta_Activo = :esta_Activo) " +  // CORREGIDO
	           "ORDER BY p.nombre")
	List<PirataDTO> buscarPiratasConFiltros(
            @Param("id") Integer id,
            @Param("nombre") String nombre,
            @Param("frutadeldiablo") String frutadeldiablo,
            @Param("esta_Activo") Boolean esta_Activo);
}
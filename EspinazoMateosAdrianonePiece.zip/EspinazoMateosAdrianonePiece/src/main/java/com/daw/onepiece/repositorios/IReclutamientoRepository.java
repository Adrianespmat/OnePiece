package com.daw.onepiece.repositorios;

import com.daw.onepiece.entities.ReclutamientoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IReclutamientoRepository extends JpaRepository<ReclutamientoEntity, Integer> {
}
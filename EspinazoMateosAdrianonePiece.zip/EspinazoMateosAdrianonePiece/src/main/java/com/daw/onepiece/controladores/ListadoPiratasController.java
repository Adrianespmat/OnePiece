package com.daw.onepiece.controladores;

import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.dtos.IslaDTO;
import com.daw.onepiece.servicio.interfaces.IPiratasService;
import com.daw.onepiece.servicio.interfaces.IIslaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/piratas")
public class ListadoPiratasController {

    @Autowired
    private IPiratasService pirataService;
    
    @Autowired
    private IIslaService islasService;

    
    @GetMapping("/listadoPiratas")
    public String mostrarFormularioFiltros(Model model) {
        model.addAttribute("filtroId", "");
        model.addAttribute("filtroNombre", "");
        model.addAttribute("filtroFruta", "");
        model.addAttribute("filtroActivo", "");
        model.addAttribute("lista", new ArrayList<PirataDTO>());
        return "piratas/listadoPiratas"; 
    }

    @PostMapping("/listadoPiratas")
    public String buscarPiratas(
            @RequestParam(value = "id", required = false) String id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "frutaDiablo", required = false) String frutaDiablo,
            @RequestParam(value = "activo", required = false) String activo,
            Model model) {
        
       
        
        Integer idFiltro = null;
        Boolean activoFiltro = null;
        
        if (id != null && !id.trim().isEmpty()) {
            try {
                idFiltro = Integer.parseInt(id);
            } catch (NumberFormatException e) {
               
            }
        }
        
        if (activo != null && !activo.trim().isEmpty()) {
            activoFiltro = activo.equals("1") || activo.equalsIgnoreCase("true");
        }
        
        List<PirataDTO> piratas = pirataService.buscarPiratasConFiltros(
            idFiltro, nombre, frutaDiablo, activoFiltro);
        
        if (piratas == null) {
            piratas = new ArrayList<>();
        }
        
        
        for (PirataDTO pirata : piratas) {
            if (pirata.getEstaActivo() == null) {
                pirata.setEstaActivo(true);
            }
            
        }
        
        model.addAttribute("filtroId", id != null ? id : "");
        model.addAttribute("filtroNombre", nombre != null ? nombre : "");
        model.addAttribute("filtroFruta", frutaDiablo != null ? frutaDiablo : "");
        model.addAttribute("filtroActivo", activo != null ? activo : "");
        model.addAttribute("lista", piratas);
        
        
        return "piratas/listadoPiratas";
    }

    
    @GetMapping("/insertarPirata")
    public String mostrarFormularioCrear(Model model) { 
        
        PirataDTO pirataDTO = new PirataDTO();
        model.addAttribute("pirataDTO", pirataDTO);
        
        List<IslaDTO> desplegableIslas = islasService.obtenerTodasIslas();
        if (desplegableIslas == null) {
            desplegableIslas = new ArrayList<>();
        }
        
        model.addAttribute("desplegableIslas", desplegableIslas);
        model.addAttribute("resultado", 0);
        
        return "piratas/insertarPirata";
    }

    @PostMapping("/insertarPirata")
    public String crearPirata(
            @RequestParam String nombre,
            @RequestParam(required = false) String frutaDiablo,
            @RequestParam String fechaNacimiento,
            @RequestParam Integer islas,
            @RequestParam(required = false, defaultValue = "0") String activo,
            Model model) {
        
        Integer resultado = 0;
        
        try {
            if (nombre == null || nombre.trim().isEmpty()) {
                throw new IllegalArgumentException("El nombre es requerido");
            }
            
            if (fechaNacimiento == null || fechaNacimiento.trim().isEmpty()) {
                throw new IllegalArgumentException("La fecha de nacimiento es requerida");
            }
            
            LocalDate fechaNac = LocalDate.parse(fechaNacimiento);
            
            PirataDTO pirataDTO = new PirataDTO();
            pirataDTO.setNombre(nombre.trim());
            
            if (frutaDiablo != null && !frutaDiablo.trim().isEmpty()) {
                pirataDTO.setFrutaDiablo(frutaDiablo.trim());
            } else {
                pirataDTO.setFrutaDiablo(null);
            }
            
            pirataDTO.setFechaNacimiento(fechaNac);
            
            Boolean estaActivo = "1".equals(activo);
            pirataDTO.setEstaActivo(estaActivo);
            
            pirataDTO.setIslaId(islas);
            
            resultado = pirataService.crearPirata(pirataDTO);
            
            if (resultado != null && resultado > 0) {
        
            } else {
                resultado = 0;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            resultado = 0;
        }
        
        model.addAttribute("resultado", resultado);
        
        List<IslaDTO> desplegableIslas = islasService.obtenerTodasIslas();
        if (desplegableIslas == null) {
            desplegableIslas = new ArrayList<>();
        }
        model.addAttribute("desplegableIslas", desplegableIslas);
        
        if (resultado > 0) {
            model.addAttribute("pirataDTO", new PirataDTO());
        }
        
        return "piratas/insertarPirata";
    }


    @GetMapping("/formularioActualizarPiratas")
    public String mostrarBusquedaEditar(Model model) {
        
        List<PirataDTO> listaVacia = new ArrayList<>();
        Integer resultado = 0;
        List<IslaDTO> desplegableIslas = islasService.obtenerTodasIslas();
        
        if (desplegableIslas == null) {
            desplegableIslas = new ArrayList<>();
        }
        
        model.addAttribute("lista", listaVacia); 
        model.addAttribute("resultado", resultado); 
        model.addAttribute("desplegableIslas", desplegableIslas);
        
        return "piratas/actualizarPiratas";
    }
    
    @PostMapping("/formularioActualizarPiratas")
    public String buscarParaActualizar(
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String frutaDiablo,
            @RequestParam(required = false, defaultValue = "1") String activo,
            Model model) {

        
        Boolean activoFiltro = null;
        if (activo != null) {
            activoFiltro = activo.equals("1");
        }

        List<PirataDTO> lista = pirataService.buscarPiratasConFiltros(
                id, nombre, frutaDiablo, activoFiltro
        );
        
        if (lista == null) {
            lista = new ArrayList<>();
        }
        
        List<IslaDTO> desplegableIslas = islasService.obtenerTodasIslas();
        if (desplegableIslas == null) {
            desplegableIslas = new ArrayList<>();
        }
        
        Integer resultado = 0;

        model.addAttribute("lista", lista);
        model.addAttribute("desplegableIslas", desplegableIslas);
        model.addAttribute("resultado", resultado);

        
        return "piratas/actualizarPiratas";
    }

    @PostMapping("/actualizarPirata")
    public String editarPirata(
            @RequestParam Integer id,
            @RequestParam String nombre,
            @RequestParam(required = false) String frutaDiablo,
            @RequestParam String fechaNacimiento,
            @RequestParam(required = false) String activo,
            @RequestParam Integer isla,
            Model model) {
        
        
        Integer resultado = 0;
        List<PirataDTO> listaActualizada = new ArrayList<>();
        
        try {
            if (nombre == null || nombre.trim().isEmpty()) {
                throw new IllegalArgumentException("El nombre es requerido");
            }
            
            if (fechaNacimiento == null || fechaNacimiento.trim().isEmpty()) {
                throw new IllegalArgumentException("La fecha de nacimiento es requerida");
            }
            
            LocalDate fechaNac = LocalDate.parse(fechaNacimiento);
            
            PirataDTO pirataDTO = new PirataDTO();
            pirataDTO.setId(id);
            pirataDTO.setNombre(nombre.trim());
            
            if (frutaDiablo != null && !frutaDiablo.trim().isEmpty()) {
                pirataDTO.setFrutaDiablo(frutaDiablo.trim());
            } else {
                pirataDTO.setFrutaDiablo(null);
            }
            
            pirataDTO.setFechaNacimiento(fechaNac);
            
            Boolean estaActivo = "1".equals(activo);
            pirataDTO.setEstaActivo(estaActivo);
            
            pirataDTO.setIslaId(isla);
            
            resultado = pirataService.actualizarPirata(pirataDTO);
            
            if (resultado != null && resultado > 0) {
                PirataDTO pirataActualizado = pirataService.obtenerPirataPorId(id);
                if (pirataActualizado != null) {
                    listaActualizada.add(pirataActualizado);
                }
            } else {
                resultado = 0;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            resultado = -1;
        }
        
        List<IslaDTO> desplegableIslas = islasService.obtenerTodasIslas();
        if (desplegableIslas == null) {
            desplegableIslas = new ArrayList<>();
        }
        
        model.addAttribute("lista", listaActualizada);
        model.addAttribute("resultado", resultado);
        model.addAttribute("desplegableIslas", desplegableIslas);
        
        return "piratas/actualizarPiratas";
    }


    @GetMapping("/formularioBorrarPiratas")
    public String mostrarBusquedaEliminar(Model model) {
        model.addAttribute("lista", new ArrayList<PirataDTO>());  
        model.addAttribute("resultado", 0);  
        return "piratas/borrarPiratas";
    }
    
    @PostMapping("/formularioBorrarPiratas")
    public String buscarParaEliminar(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String nombre,
            Model model) {
        
        System.out.println("/piratas/formularioBorrarPiratas");
        
        Integer idFiltro = null;
        if (id != null && !id.trim().isEmpty()) {
            try {
                idFiltro = Integer.parseInt(id);
            } catch (NumberFormatException e) {
                
                idFiltro = null;
            }
        }
        
        List<PirataDTO> piratas = pirataService.buscarPiratasConFiltros(
            idFiltro, nombre, null, true);
        
        if (piratas == null) {
            piratas = new ArrayList<>();
        }
        
        model.addAttribute("lista", piratas);
        model.addAttribute("resultado", 0);
        
        return "piratas/borrarPiratas";
    }
    
    @PostMapping("/borrarPirata")
    public String eliminarPirata(
            @RequestParam Integer id,
            Model model) {
        
 
        
        Integer resultado = 0;
        try {
            pirataService.eliminarPirata(id);
            resultado = id;
            
        } catch (Exception e) {
            
            e.printStackTrace();
            resultado = -1;
        }
        
        model.addAttribute("resultado", resultado);  
        model.addAttribute("lista", new ArrayList<PirataDTO>());
        
        return "piratas/borrarPiratas";
    }
    
    
}
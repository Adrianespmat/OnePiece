package com.daw.onepiece.controladores;

import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.dtos.IslaDTO;
import com.daw.onepiece.servicio.interfaces.IPiratasService;
import com.daw.onepiece.servicio.interfaces.IIslaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/piratas")
public class ListadoPiratasController {

    @Autowired
    private IPiratasService pirataService;
    
    @Autowired
    private IIslaService islasService;

    @GetMapping("/listadoPiratas")
    public String mostrarFormularioFiltros(Model model) {
        model.addAttribute("filtroId", "");
        model.addAttribute("filtroNombre", "");
        model.addAttribute("filtroFruta", "");
        model.addAttribute("filtroActivo", "");
        model.addAttribute("listaPiratas", null);
        return "piratas/listadoPiratas"; 
    }

    @PostMapping("/listadoPiratas")
    public String buscarPiratas(
            @RequestParam(value = "id", required = false) String id,
            @RequestParam(value = "nombre", required = false) String nombre,
            @RequestParam(value = "frutadeldiablo", required = false) String frutadeldiablo,
            @RequestParam(value = "activo", required = false) String activo,
            Model model) {
        
        Integer idFiltro = null;
        Boolean activoFiltro = null;
        
        if (id != null && !id.trim().isEmpty()) {
            idFiltro = Integer.parseInt(id);
        }
        
        if (activo != null && !activo.trim().isEmpty()) {
            activoFiltro = activo.equals("1") || activo.equalsIgnoreCase("true");
        }
        
        List<PirataDTO> piratas = pirataService.buscarPiratasConFiltros(
            idFiltro, nombre, frutadeldiablo, activoFiltro);
        
        model.addAttribute("filtroId", id != null ? id : "");
        model.addAttribute("filtroNombre", nombre != null ? nombre : "");
        model.addAttribute("filtroFruta", frutadeldiablo != null ? frutadeldiablo : "");
        model.addAttribute("filtroActivo", activo != null ? activo : "");
        model.addAttribute("listaPiratas", piratas);
        
        return "piratas/listadoPiratas";
    }

    @GetMapping("/insertarPirata")
    public String mostrarFormularioCrear(Model model) {
        model.addAttribute("pirataDTO", new PirataDTO());
        List<IslaDTO> desplegableIslas = islasService.obtenerTodasIslas();
        model.addAttribute("desplegableIslas", desplegableIslas);
        return "piratas/insertarPirata";
    }

    @PostMapping("/insertarPirata")
    public String crearPirata(
            @RequestParam String nombre,
            @RequestParam(required = false) String frutaDiablo,
            @RequestParam String fechaNacimiento,
            @RequestParam Integer islas, // Mantener Integer (ID)
            @RequestParam(required = false, defaultValue = "0") String activo,
            Model model) {
        
        LocalDate fechaNac = LocalDate.parse(fechaNacimiento);
        
        PirataDTO pirataDTO = new PirataDTO();
        pirataDTO.setNombre(nombre);
        pirataDTO.setFrutaDelDiablo(frutaDiablo);
        pirataDTO.setFechaNacimiento(fechaNac);
        
        boolean estaActivo = "1".equals(activo);
        pirataDTO.setEstaActivo(estaActivo);
        
        // Usar setIslaId() con el Integer
        pirataDTO.setIslaId(islas);
        
        Integer resultado = pirataService.crearPirata(pirataDTO);
        
        model.addAttribute("resultado", resultado);
        List<IslaDTO> desplegableIslas = islasService.obtenerTodasIslas();
        model.addAttribute("desplegableIslas", desplegableIslas);
        
        return "piratas/insertarPirata";
    }

    @GetMapping("/formularioActualizarPiratas")
    public String mostrarBusquedaEditar(Model model) {
        List<PirataDTO> listaVacia = new ArrayList<>();
        
        // Inicializar atributos que Thymeleaf espera
        for (PirataDTO p : listaVacia) {
            if (p.getEstaActivo() == null) p.setEstaActivo(false);
            if (p.getIslaId() == null) p.setIslaId(0);
        }

        model.addAttribute("lista", listaVacia); 
        model.addAttribute("resultado", 0); 
        model.addAttribute("desplegableIslas", islasService.obtenerTodasIslas());
        return "piratas/actualizarPiratas";
    }
    
    @PostMapping("/formularioActualizarPiratas")
    public String buscarParaActualizar(
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String frutaDiablo,
            @RequestParam(required = false) String activo,
            Model model) {

        Boolean activoFiltro = null;
        if (activo != null) {
            activoFiltro = activo.equals("1");
        }

        List<PirataDTO> lista = pirataService.buscarPiratasConFiltros(
                id, nombre, frutaDiablo, activoFiltro
        );

        model.addAttribute("lista", lista);
        model.addAttribute("desplegableIslas", islasService.obtenerTodasIslas());

        return "piratas/actualizarPiratas";
    }


    

    @PostMapping("/actualizarPirata")
    public String editarPirata(
            @RequestParam Integer id,
            @RequestParam String nombre,
            @RequestParam(required = false) String frutaDiablo,
            @RequestParam String fechaNacimiento,
            @RequestParam(required = false) String activo,
            @RequestParam Integer isla,
            Model model) {

        PirataDTO pirataDTO = new PirataDTO();
        pirataDTO.setId(id);
        pirataDTO.setNombre(nombre);
        pirataDTO.setFrutaDelDiablo(frutaDiablo);
        pirataDTO.setFechaNacimiento(LocalDate.parse(fechaNacimiento));
        pirataDTO.setEstaActivo("1".equals(activo));
        pirataDTO.setIslaId(isla);

        pirataService.actualizarPirata(pirataDTO);
        model.addAttribute("resultado", 1);
        model.addAttribute("desplegableIslas", islasService.obtenerTodasIslas());

        return "piratas/actualizarPiratas";
    }


    @GetMapping("/eliminar")
    public String mostrarBusquedaEliminar(Model model) {
        return "piratas/borrarPiratas";
    }

    @PostMapping("/buscarParaEliminar")
    public String buscarParaEliminar(
            @RequestParam(required = false) Integer id,
            @RequestParam(required = false) String nombre,
            Model model) {
        
        List<PirataDTO> piratas = pirataService.buscarPiratasConFiltros(id, nombre, null, true);
        
        if (piratas.size() == 1) {
            model.addAttribute("pirataDTO", piratas.get(0));
            return "piratas/confirmarEliminar";
        } else {
            model.addAttribute("piratasEncontrados", piratas);
            return "piratas/resultadosBusquedaEliminar";
        }
    }

    @PostMapping("/eliminar")
    public String eliminarPirata(@RequestParam Integer id) {
        pirataService.eliminarPirata(id);
        return "piratas/listadoPiratas";
    }
}
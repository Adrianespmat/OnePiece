package com.daw.onepiece.servicio.impl;

import com.daw.onepiece.dao.interfaces.IRecompensaDAO;
import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.servicio.interfaces.IRecompensaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class RecompensaServiceImpl implements IRecompensaService {

    @Autowired
    private IRecompensaDAO recompensaDAO;

    @Override
    public List<RecompensaDTO> obtenerRecompensasConFiltros(String nombrePirata, Integer idTripulacion, 
                                                          Integer cantidadMinima, Boolean soloVigentes) {
        System.out.println("✅ Service: obtenerRecompensasConFiltros");
        // Convertir Integer a BigDecimal para el DAO
        BigDecimal cantidadMinimaBD = null;
        if (cantidadMinima != null) {
            cantidadMinimaBD = BigDecimal.valueOf(cantidadMinima);
        }
        return recompensaDAO.obtenerRecompensasConFiltros(nombrePirata, idTripulacion, 
                                                         cantidadMinimaBD, soloVigentes);
    }

    @Override
    public List<TripulacionDTO> obtenerTripulacionesActivas() {
        System.out.println("✅ Service: obtenerTripulacionesActivas");
        return recompensaDAO.obtenerTripulacionesActivas();
    }

    @Override
    public Integer emitirRecompensa(Integer idPirata, BigDecimal cantidad) {
        System.out.println("✅ Service: emitirRecompensa - Pirata: " + idPirata + ", Cantidad: " + cantidad);
        return recompensaDAO.emitirRecompensa(idPirata, cantidad);
    }

    @Override
    public Integer actualizarRecompensa(Integer id, Integer idPirata, BigDecimal cantidad, Boolean estaVigente) {
        System.out.println("✅ Service: actualizarRecompensa ID: " + id);
        return recompensaDAO.actualizarRecompensa(id, idPirata, cantidad, estaVigente);
    }

    @Override
    public void eliminarRecompensa(Integer id) {
        System.out.println("✅ Service: eliminarRecompensa ID: " + id);
        recompensaDAO.eliminarRecompensa(id);
    }
}
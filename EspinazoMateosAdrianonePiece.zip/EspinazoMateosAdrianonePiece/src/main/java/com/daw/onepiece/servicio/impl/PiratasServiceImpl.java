package com.daw.onepiece.servicio.impl;

import com.daw.onepiece.dao.interfaces.IPiratasDAO;
import com.daw.onepiece.dtos.PirataDTO;
import com.daw.onepiece.servicio.interfaces.IPiratasService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PiratasServiceImpl implements IPiratasService {

    @Autowired
    private IPiratasDAO piratasDAO;

    @Override
    public List<PirataDTO> buscarPiratasConFiltros(Integer id, String nombre, String frutadeldiablo, Boolean esta_Activo) {
        return piratasDAO.buscarPiratasConFiltros(id, nombre, frutadeldiablo, esta_Activo);
    }

    @Override
    public List<PirataDTO> TodosLosPiratas() {
        // Si necesitas este método, implementa en DAO primero
        return piratasDAO.buscarPiratasConFiltros(null, null, null, null);
    }

    @Override
    public Integer crearPirata(PirataDTO pirataDTO) {
        return piratasDAO.crearPirata(pirataDTO);
    }

    @Override
    public Integer actualizarPirata(PirataDTO pirataDTO) {
        return piratasDAO.actualizarPirata(pirataDTO);
    }

    @Override
    public void eliminarPirata(Integer id) {
        piratasDAO.eliminarPirata(id);
    }

    @Override
    public PirataDTO obtenerPirataPorId(Integer id) {
        return piratasDAO.obtenerPirataPorId(id);
    }
}
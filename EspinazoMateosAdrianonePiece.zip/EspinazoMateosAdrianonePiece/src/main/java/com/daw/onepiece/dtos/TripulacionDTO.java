package com.daw.onepiece.dtos;

public class TripulacionDTO {
    private Integer id; // ✅ CAMBIADO de Long a Integer
    private String nombre;
    private String barco;
    private Boolean estaActiva;
    private Integer numeroMiembros;
    
    public TripulacionDTO() {
    }
    
    public TripulacionDTO(Integer id, String nombre, String barco, Boolean estaActiva) { // ✅ CAMBIADO
        this.id = id;
        this.nombre = nombre;
        this.barco = barco;
        this.estaActiva = estaActiva;
    }
    
    public TripulacionDTO(Integer id, String nombre, String barco, Boolean estaActiva, Integer numeroMiembros) { // ✅ CAMBIADO
        this.id = id;
        this.nombre = nombre;
        this.barco = barco;
        this.estaActiva = estaActiva;
        this.numeroMiembros = numeroMiembros;
    }
    
    // Getters y Setters
    public Integer getId() { // ✅ CAMBIADO
        return id;
    }
    
    public void setId(Integer id) { // ✅ CAMBIADO
        this.id = id;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getBarco() {
        return barco;
    }
    
    public void setBarco(String barco) {
        this.barco = barco;
    }
    
    public Boolean getEstaActiva() {
        return estaActiva;
    }
    
    public void setEstaActiva(Boolean estaActiva) {
        this.estaActiva = estaActiva;
    }
    
    public Integer getNumeroMiembros() {
        return numeroMiembros;
    }
    
    public void setNumeroMiembros(Integer numeroMiembros) {
        this.numeroMiembros = numeroMiembros;
    }
    
    // Método para vistas
    public String getEstadoTexto() {
        return estaActiva != null && estaActiva ? "Activa" : "Inactiva";
    }
    
    public Integer getActiva() {
        return estaActiva != null && estaActiva ? 1 : 0;
    }
    
    public void setActiva(Integer activa) {
        this.estaActiva = (activa != null && activa == 1);
    }
}
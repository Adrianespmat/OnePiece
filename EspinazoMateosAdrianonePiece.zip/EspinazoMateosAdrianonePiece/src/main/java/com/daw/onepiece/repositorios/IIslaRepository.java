package com.daw.onepiece.repositorios;

import com.daw.onepiece.entities.IslaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IIslaRepository extends JpaRepository<IslaEntity, Integer> {
    
    IslaEntity findByNombre(String nombre);
}
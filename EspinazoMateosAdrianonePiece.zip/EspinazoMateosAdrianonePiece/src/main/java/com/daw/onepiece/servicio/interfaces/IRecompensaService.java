package com.daw.onepiece.servicio.interfaces;

import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.dtos.TripulacionDTO;
import java.math.BigDecimal;
import java.util.List;

public interface IRecompensaService {
    List<RecompensaDTO> obtenerRecompensasConFiltros(String nombrePirata, Integer idTripulacion,
                                                     Integer cantidadMinima, Boolean soloVigentes);
    
    List<TripulacionDTO> obtenerTripulacionesActivas();
    
    Integer emitirRecompensa(Integer idPirata, BigDecimal cantidad); // Emitir usa BigDecimal del Controller
    
    
    
    void eliminarRecompensa(Integer id);

	Integer actualizarRecompensa(Integer id, Integer idPirata, BigDecimal cantidad, Boolean vigente);
}
package com.daw.onepiece.servicio.interfaces;

import com.daw.onepiece.dtos.IslaDTO;
import java.util.List;

public interface IIslaService {
    List<IslaDTO> obtenerTodasIslas();
}
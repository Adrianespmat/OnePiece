package com.daw.onepiece.entities;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "Pirata") 
public class PirataEntity {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "`frutaDelDiablo`") 
    private String frutadeldiablo;

    @Column(name = "`fechaNacimiento`") 
    private LocalDate fechaNacimiento;

    @Column(name = "`estaActivo`") 
    private Boolean esta_Activo;

    @ManyToOne
    @JoinColumn(name = "isla_id") 
    private IslaEntity isla;

    public PirataEntity() {
    }

    public PirataEntity(Integer id, String nombre, String frutadeldiablo, LocalDate fechaNacimiento, 
                       Boolean esta_Activo, IslaEntity isla) {
        this.id = id;
        this.nombre = nombre;
        this.frutadeldiablo = frutadeldiablo;
        this.fechaNacimiento = fechaNacimiento;
        this.esta_Activo = esta_Activo;
        this.isla = isla;
    }

    // Getters y setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFrutaDelDiablo() {
        return frutadeldiablo;
    }

    public void setFrutaDelDiablo(String frutadeldiablo) {
        this.frutadeldiablo = frutadeldiablo;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Boolean getEstaActivo() {
        return esta_Activo;
    }

    public void setEstaActivo(Boolean esta_Activo) {
        this.esta_Activo = esta_Activo;
    }

    public IslaEntity getIsla() {
        return isla;
    }

    public void setIsla(IslaEntity isla) {
        this.isla = isla;
    }
}
package com.daw.onepiece.dao.interfaces;

import com.daw.onepiece.dtos.TripulacionDTO;
import com.daw.onepiece.dtos.DetalleTripulacionDTO;
import com.daw.onepiece.dtos.PirataDTO;

import java.util.List;

public interface ITripulacionDAO {
    List<TripulacionDTO> obtenerTodasTripulacionesConMiembros();
    DetalleTripulacionDTO obtenerDetalleTripulacion(Integer id); // ✅ CAMBIADO
    Integer crearTripulacion(TripulacionDTO tripulacionDTO); // ✅ CAMBIADO
    Integer actualizarTripulacion(TripulacionDTO tripulacionDTO); // ✅ CAMBIADO
    void eliminarTripulacion(Integer id); // ✅ CAMBIADO
    void agregarMiembroATripulacion(Integer tripulacionId, Integer pirataId, String rol); // ✅ CAMBIADO
    void eliminarMiembroDeTripulacion(Integer reclutamientoId);
    List<PirataDTO> obtenerPiratasDisponibles();
}
package com.daw.onepiece.dao.interfaces;

import com.daw.onepiece.dtos.RecompensaDTO;
import com.daw.onepiece.dtos.TripulacionDTO;
import java.math.BigDecimal;
import java.util.List;

public interface IRecompensaDAO {
    List<RecompensaDTO> obtenerRecompensasConFiltros(String nombrePirata, Integer idTripulacion, 
                                                     BigDecimal cantidadMinima, Boolean soloVigentes);
    
    List<TripulacionDTO> obtenerTripulacionesActivas();
    
    Integer emitirRecompensa(Integer idPirata, BigDecimal cantidad);
    
    Integer actualizarRecompensa(Integer id, Integer idPirata, BigDecimal cantidad, Boolean estaVigente);
    
    void eliminarRecompensa(Integer id);
}